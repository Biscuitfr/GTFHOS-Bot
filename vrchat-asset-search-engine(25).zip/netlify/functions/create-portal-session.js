const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { userId } = JSON.parse(event.body);

    if (!userId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing userId' }) };
    }

    // Find customer by metadata
    const customers = await stripe.customers.list({
      limit: 100,
      metadata: { userId }
    });

    if (customers.data.length === 0) {
      return { statusCode: 404, body: JSON.stringify({ error: 'No subscription found' }) };
    }

    const customer = customers.data[0];

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: customer.id,
      return_url: `${process.env.VITE_API_BASE_URL || 'https://vrcnexus.netlify.app'}/?billing=portal_return`
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ url: portalSession.url })
    };

  } catch (error) {
    console.error('Portal session error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to create billing portal session' })
    };
  }
};
