const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid signature' }) };
  }

  try {
    const handleSubscriptionUpdate = async (subscription) => {
      const customerId = subscription.customer;
      const priceId = subscription.items.data[0]?.price?.id;
      
      let plan = 'free';
      if (priceId === process.env.STRIPE_PLUS_PRICE_ID) {
        plan = 'nexus_plus';
      } else if (priceId === process.env.STRIPE_PRO_PRICE_ID) {
        plan = 'nexus_pro';
      }

      const status = subscription.status === 'canceled' ? 'free' : plan;
      
      // Store subscription status (in a real app, you'd update your database here)
      // For now, we'll store it in Netlify's environment or a database
      console.log(`Subscription ${subscription.id} updated: plan=${status}, customer=${customerId}`);
      
      return { plan: status, status: subscription.status };
    };

    switch (stripeEvent.type) {
      case 'checkout.session.completed': {
        const session = stripeEvent.data.object;
        if (session.subscription) {
          const subscription = await stripe.subscriptions.retrieve(session.subscription);
          await handleSubscriptionUpdate(subscription);
        }
        break;
      }
      
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const subscription = stripeEvent.data.object;
        await handleSubscriptionUpdate(subscription);
        break;
      }
      
      default:
        console.log(`Unhandled event type: ${stripeEvent.type}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ received: true })
    };

  } catch (error) {
    console.error('Webhook processing error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Webhook processing failed' })
    };
  }
};
