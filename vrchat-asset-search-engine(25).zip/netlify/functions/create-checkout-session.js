const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { userId, email, plan } = JSON.parse(event.body);

    if (!userId || !email || !plan) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing required fields' }) };
    }

    const priceId = plan === 'nexus_plus' 
      ? process.env.STRIPE_PLUS_PRICE_ID 
      : process.env.STRIPE_PRO_PRICE_ID;

    if (!priceId) {
      return { statusCode: 500, body: JSON.stringify({ error: 'Stripe price not configured' }) };
    }

    // Find or create customer
    let customer;
    const existingCustomers = await stripe.customers.list({ email, limit: 1 });
    
    if (existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await stripe.customers.create({
        email,
        metadata: { userId }
      });
    }

    // Check for existing subscription
    const subscriptions = await stripe.subscriptions.list({
      customer: customer.id,
      status: 'all',
      limit: 1
    });

    // If active subscription exists, update it (upgrade/downgrade)
    if (subscriptions.data.length > 0 && ['active', 'trialing', 'past_due'].includes(subscriptions.data[0].status)) {
      const subscription = subscriptions.data[0];
      const itemId = subscription.items.data[0].id;
      
      await stripe.subscriptions.update(subscription.id, {
        cancel_at_period_end: false,
        proration_behavior: 'create_prorations',
        items: [{ id: itemId, price: priceId }]
      });

      return {
        statusCode: 200,
        body: JSON.stringify({ updated: true, subscriptionId: subscription.id })
      };
    }

    // Create new checkout session
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customer.id,
      line_items: [{ price: priceId, quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${process.env.VITE_API_BASE_URL || 'https://vrcnexus.netlify.app'}/?billing=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.VITE_API_BASE_URL || 'https://vrcnexus.netlify.app'}/?billing=cancel`,
      subscription_data: {
        metadata: { userId, plan }
      }
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ url: session.url, sessionId: session.id })
    };

  } catch (error) {
    console.error('Checkout session error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to create checkout session. Please try again.' })
    };
  }
};
