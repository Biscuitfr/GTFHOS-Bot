const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { userId } = event.queryStringParameters || {};

    if (!userId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing userId' }) };
    }

    // Find customer by metadata
    const customers = await stripe.customers.list({
      limit: 100,
      metadata: { userId }
    });

    if (customers.data.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({ plan: 'free', status: 'none' })
      };
    }

    const customer = customers.data[0];
    const subscriptions = await stripe.subscriptions.list({
      customer: customer.id,
      status: 'all',
      limit: 1
    });

    if (subscriptions.data.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({ plan: 'free', status: 'none' })
      };
    }

    const subscription = subscriptions.data[0];
    const priceId = subscription.items.data[0]?.price?.id;
    
    let plan = 'free';
    if (priceId === process.env.STRIPE_PLUS_PRICE_ID) {
      plan = 'nexus_plus';
    } else if (priceId === process.env.STRIPE_PRO_PRICE_ID) {
      plan = 'nexus_pro';
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        plan: subscription.status === 'canceled' ? 'free' : plan,
        status: subscription.status,
        currentPeriodEnd: subscription.current_period_end,
        cancelAtPeriodEnd: subscription.cancel_at_period_end
      })
    };

  } catch (error) {
    console.error('Subscription status error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to fetch subscription status' })
    };
  }
};
