-- ============================================================
--  VRC NEXUS — Supabase database migration
--  Run this in: Supabase Dashboard > SQL Editor > New query
-- ============================================================

-- ---- 1. Profiles table (extends auth.users) ----
create table if not exists public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  username        text unique not null,
  email           text not null,
  avatar_url      text,
  plan            text not null default 'free'
                    check (plan in ('free','nexus_plus','nexus_pro')),
  stripe_customer_id text,
  created_at      timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.profiles enable row level security;

-- Each user can only read / update their own profile
create policy "Users can view their own profile"
  on public.profiles for select
  using ( auth.uid() = id );

create policy "Users can update their own profile"
  on public.profiles for update
  using ( auth.uid() = id );

-- Allow insert from the trigger below
create policy "Service can insert profile"
  on public.profiles for insert
  with check (true);

-- ---- 2. Automatically create a profile row when a user signs up ----
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, email, avatar_url)
  values (
    new.id,
    -- Use the display_name metadata the client sends; fallback to the email prefix.
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    new.email,
    null
  );
  return new;
end;
$$;

-- Drop trigger if it already exists (idempotent re-run safety)
drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---- 3. Allow the billing server (service role) to update plan & stripe_customer_id ----
-- The Node/Express billing server uses the service_role key (server-side only)
-- and can bypass RLS to sync subscription status from Stripe webhooks.
-- No extra policy needed for service_role since it bypasses RLS by default.

-- ---- 4. Daily usage tracking table ----
create table if not exists public.usage (
  id          bigserial primary key,
  user_id     uuid not null references auth.users(id) on delete cascade,
  kind        text not null,          -- 'ai' | 'web'
  day         date not null default current_date,
  count       integer not null default 0,
  unique (user_id, kind, day)
);

alter table public.usage enable row level security;

create policy "Users can manage their own usage"
  on public.usage for all
  using ( auth.uid() = user_id )
  with check ( auth.uid() = user_id );
