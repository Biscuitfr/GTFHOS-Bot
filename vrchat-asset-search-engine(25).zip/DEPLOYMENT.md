# VRC NEXUS — Netlify Deployment Guide

## 1. Set up Netlify Environment Variables

In your Netlify dashboard, go to **Site settings → Environment variables** and add:

```
STRIPE_SECRET_KEY=sk_live_...          # Your Stripe secret key
STRIPE_WEBHOOK_SECRET=whsec_...        # Webhook signing secret
STRIPE_PLUS_PRICE_ID=price_...         # Nexus Plus price ID (€4.99/month)
STRIPE_PRO_PRICE_ID=price_...          # Nexus Pro price ID (€9.99/month)
VITE_API_BASE_URL=https://vrcnexus.netlify.app
```

## 2. Configure Stripe Webhook

In Stripe Dashboard → Developers → Webhooks:

1. Add endpoint: `https://vrcnexus.netlify.app/.netlify/functions/stripe-webhook`
2. Select events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
3. Copy the signing secret → `STRIPE_WEBHOOK_SECRET`

## 3. Deploy

Push to your repository. Netlify will automatically:
- Build the frontend (`npm run build`)
- Deploy the Netlify Functions

## 4. Test

1. Visit https://vrcnexus.netlify.app
2. Sign up for an account
3. Go to Premium Plans
4. Click "Upgrade to Plus" or "Go Pro"
5. Complete Stripe Checkout
6. Return to the site — your subscription should be active

## 5. Pricing Page

The pricing page shows exactly 3 cards:
- **Free** — Limited features
- **Nexus Plus** — €4.99/month
- **Nexus Pro** — €9.99/month

No Ultimate plan visible.

## 6. Error Handling

All API endpoints return valid JSON. If Stripe is unavailable, users see friendly error messages instead of crashes.

## 7. Security

- Stripe secret key is stored only in Netlify environment variables
- Never exposed in frontend code
- Webhook signature verification prevents unauthorized requests
- All functions return proper JSON responses
