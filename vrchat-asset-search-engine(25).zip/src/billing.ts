// ============================================================
//  VRC NEXUS — Frontend billing client
//  Talks to the server-side Stripe backend (see /server).
//  NO secret keys here — only the public API base URL.
//
//  If VITE_API_BASE_URL is not configured, the app runs in a
//  safe DEMO mode so the UI is fully previewable without charges.
// ============================================================

export type PlanId = 'free' | 'nexus_plus' | 'nexus_pro';

export interface SubscriptionState {
  plan: PlanId;
  status: string; // active | trialing | canceled | none | demo ...
  currentPeriodEnd?: number;
  cancelAtPeriodEnd?: boolean;
}

export interface PlanFeature {
  label: string;
  included: boolean;
}

export interface PlanDef {
  id: PlanId;
  name: string;
  priceLabel: string;
  priceSub: string;
  highlight?: boolean;
  badge?: string;
  tagline: string;
  features: PlanFeature[];
  cta: string;
}

// Per-plan limits used to gate features across the app.
export interface PlanLimits {
  aiSearchesPerDay: number;       // -1 = unlimited
  webSearchesPerDay: number;      // -1 = unlimited
  avatarUploads: number;          // -1 = unlimited
  favorites: number;              // -1 = unlimited
  searchPriority: 'slow' | 'fast' | 'priority';
  vrcBot: 'basic' | 'premium' | 'advanced';
  profileSimulator: boolean;
  vrchatIdCard: boolean;
}

export const PLAN_LIMITS: Record<PlanId, PlanLimits> = {
  free: {
    aiSearchesPerDay: 5,
    webSearchesPerDay: 3,
    avatarUploads: 2,
    favorites: 10,
    searchPriority: 'slow',
    vrcBot: 'basic',
    profileSimulator: false,
    vrchatIdCard: false,
  },
  nexus_plus: {
    aiSearchesPerDay: 100,
    webSearchesPerDay: 50,
    avatarUploads: 50,
    favorites: 500,
    searchPriority: 'fast',
    vrcBot: 'premium',
    profileSimulator: true,
    vrchatIdCard: true,
  },
  nexus_pro: {
    aiSearchesPerDay: -1,
    webSearchesPerDay: -1,
    avatarUploads: -1,
    favorites: -1,
    searchPriority: 'priority',
    vrcBot: 'advanced',
    profileSimulator: true,
    vrchatIdCard: true,
  },
};

export const PLANS: PlanDef[] = [
  {
    id: 'free',
    name: 'Free',
    priceLabel: '€0',
    priceSub: 'forever',
    tagline: 'Get started and explore the metaverse.',
    cta: 'Current plan',
    features: [
      { included: true, label: '5 AI searches / day' },
      { included: true, label: '3 Web Discovery searches / day' },
      { included: true, label: 'Up to 2 avatar uploads' },
      { included: true, label: 'Basic VRC Bot' },
      { included: true, label: 'Up to 10 favorites' },
      { included: false, label: 'Profile Simulator' },
      { included: false, label: 'VRChat ID Card' },
      { included: false, label: 'Faster search priority' },
    ],
  },
  {
    id: 'nexus_plus',
    name: 'Nexus Plus',
    priceLabel: '€4.99',
    priceSub: 'per month',
    highlight: true,
    badge: 'Most popular',
    tagline: 'For active creators and explorers.',
    cta: 'Upgrade to Plus',
    features: [
      { included: true, label: 'Increased AI search limits' },
      { included: true, label: 'Increased Web Discovery limits' },
      { included: true, label: 'VRC Bot (basic premium)' },
      { included: true, label: 'Profile Simulator & VRChat ID Card' },
      { included: true, label: 'Higher upload limits' },
      { included: true, label: 'Faster search priority' },
      { included: false, label: 'Unlimited searches' },
      { included: false, label: 'Priority support' },
    ],
  },
  {
    id: 'nexus_pro',
    name: 'Nexus Pro',
    priceLabel: '€9.99',
    priceSub: 'per month',
    badge: 'Best value',
    tagline: 'Everything, unlimited, no limits.',
    cta: 'Go Pro',
    features: [
      { included: true, label: 'Everything in Nexus Plus' },
      { included: true, label: 'Unlimited AI searches' },
      { included: true, label: 'Unlimited Web Discovery' },
      { included: true, label: 'Unlimited avatar uploads' },
      { included: true, label: 'Advanced VRC Bot' },
      { included: true, label: 'Early access to new features' },
      { included: true, label: 'Priority support' },
    ],
  },
];

const API_BASE = (import.meta as any).env?.VITE_API_BASE_URL || 'https://vrcnexus.netlify.app';
export const BILLING_DEMO_MODE = false;

async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const url = path.startsWith('/.netlify/') 
    ? `${API_BASE}${path}`
    : `${API_BASE}/.netlify/functions${path.replace('/api/stripe', '')}`;
  
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

async function apiGet<T>(path: string): Promise<T> {
  const url = path.startsWith('/.netlify/') 
    ? `${API_BASE}${path}`
    : `${API_BASE}/.netlify/functions${path.replace('/api/stripe', '')}`;
  
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

/** Read the current subscription for a user. */
export async function fetchSubscription(userId: string): Promise<SubscriptionState> {
  try {
    return await apiGet(`/api/stripe/subscription-status?userId=${encodeURIComponent(userId)}`);
  } catch (error) {
    console.error('Failed to fetch subscription:', error);
    return { plan: 'free', status: 'none' };
  }
}

/** Start Stripe Checkout (subscribe) or switch plan (upgrade/downgrade). */
export async function startCheckout(opts: { userId: string; email: string; plan: PlanId }): Promise<void> {
  const data = await apiPost<{ url?: string; updated?: boolean }>(
    '/api/stripe/create-checkout-session',
    opts,
  );
  if (data.url) {
    window.location.href = data.url; // Redirect to Stripe Checkout
  }
  // If data.updated === true, the plan was switched on the existing subscription.
}

/** Open the Stripe Billing Portal (manage payment method, invoices, cancel). */
export async function openBillingPortal(userId: string): Promise<void> {
  const data = await apiPost<{ url: string }>('/api/stripe/create-portal-session', { userId });
  if (data.url) window.location.href = data.url;
}

/** Cancel the subscription at the end of the current period. */
export async function cancelSubscription(userId: string): Promise<void> {
  await apiPost('/api/stripe/cancel-subscription', { userId });
}



export function isPremium(plan: PlanId) {
  return plan === 'nexus_plus' || plan === 'nexus_pro';
}

export function planDisplayName(plan: PlanId) {
  if (plan === 'nexus_plus') return 'Nexus Plus';
  if (plan === 'nexus_pro') return 'Nexus Pro';
  return 'Free';
}
