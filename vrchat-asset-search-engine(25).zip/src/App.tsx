import { useMemo, useState, useEffect, type ReactNode } from 'react';
import {
  PLANS,
  PLAN_LIMITS,
  fetchSubscription,
  startCheckout,
  openBillingPortal,
  cancelSubscription,
  isPremium,
  planDisplayName,
  type PlanId,
  type SubscriptionState,
} from './billing';
import {
  signUp,
  signIn,
  signOut,
  getCurrentUser,
  sendPasswordReset,
  onAuthChange,
  SUPABASE_CONFIGURED,
  type AuthUser,
} from './auth';

type SourceId =
  | 'vrchat-worlds'
  | 'vrchat-avatars'
  | 'vrcfinder'
  | 'jinxxy'
  | 'booth'
  | 'gumroad'
  | 'itaku'
  | 'sketchfab'
  | 'payhip'
  | 'vrcdb'
  | 'community'
  | 'custom-uploads';

type ResultType = 'Avatar' | 'Monde' | 'Asset' | 'Recherche';
type SortMode = 'relevance' | 'popularity' | 'price' | 'shuffle';
type ContentMode = 'all' | 'avatars' | 'worlds' | 'assets';
type SourceState = 'idle' | 'loading' | 'done' | 'error';
type SearchTargetMode = 'keywords' | 'creator';
type ActiveTool = 'explorer' | 'bot' | 'simulator' | 'indexer' | 'community' | 'pricing';
type Platform = 'PC' | 'Quest' | 'iOS';

interface SearchResult {
  id: string;
  title: string;
  creator?: string;
  description: string;
  type: ResultType;
  source: SourceId;
  sourceLabel: string;
  url: string;
  imageUrl?: string;
  priceLabel?: string;
  priceUsd?: number;
  nsfw: boolean;
  score: number;
  actionLabel: string;
  views?: number;
  likes?: number;
  tags?: string[];
  platforms?: Platform[];
}

interface SourceOption {
  id: SourceId;
  label: string;
  detail: string;
  mode: 'all' | 'avatars' | 'worlds' | 'assets';
  color: string;
  searchUrl: (query: string, includeNSFW: boolean) => string;
}

type NeonIconName =
  | 'vr' | 'search' | 'globalSearch' | 'send' | 'filter' | 'star' | 'vrHeadset'
  | 'chat' | 'user' | 'bookmark' | 'heart' | 'history' | 'play' | 'image'
  | 'cube' | 'users' | 'tag' | 'vrcBubble' | 'home' | 'flame' | 'gamepad'
  | 'pin' | 'code' | 'shield' | 'chart' | 'lineChart' | 'eye' | 'bell'
  | 'settings' | 'bolt' | 'upload' | 'download' | 'plus' | 'trash' | 'save' | 'link' | 'check' | 'cross';

function NeonIcon({ name, size = 22, className = '' }: { name: NeonIconName; size?: number; className?: string }) {
  const common = {
    fill: 'none',
    stroke: 'url(#neonIconGradient)',
    strokeWidth: 2.2,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };

  const paths: Record<NeonIconName, ReactNode> = {
    vr: <><path d="M4 8l4.5 8L16 4"/><path d="M16 4a8 8 0 1 1-6.5 12.6"/><circle cx="18" cy="18" r="3"/><path d="M20.5 20.5L23 23"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L22 22"/></>,
    globalSearch: <><circle cx="11" cy="11" r="8"/><path d="M3 11h16M11 3c2.2 2.1 3.2 4.8 3.2 8S13.2 16.9 11 19M11 3c-2.2 2.1-3.2 4.8-3.2 8s1 5.9 3.2 8"/><circle cx="19" cy="19" r="3"/><path d="M21 21l2 2"/></>,
    send: <><circle cx="12" cy="12" r="10"/><path d="M8 13l9-5-4 9-1.5-3.5L8 13z"/></>,
    filter: <><path d="M4 5h16l-6 7v6l-4 2v-8L4 5z"/></>,
    star: <><path d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.8 6.2 20.9l1.1-6.5-4.7-4.6 6.5-.9L12 3z"/></>,
    vrHeadset: <><path d="M4 10h16a2 2 0 0 1 2 2v4a4 4 0 0 1-4 4h-2.5a3.5 3.5 0 0 1-7 0H6a4 4 0 0 1-4-4v-4a2 2 0 0 1 2-2z"/><path d="M7 10V7h10v3"/></>,
    chat: <><path d="M5 6h14a3 3 0 0 1 3 3v5a3 3 0 0 1-3 3H10l-5 4v-4a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    bookmark: <><path d="M7 4h10a1 1 0 0 1 1 1v16l-6-4-6 4V5a1 1 0 0 1 1-1z"/></>,
    heart: <><path d="M20.8 5.6a5.2 5.2 0 0 0-7.4 0L12 7l-1.4-1.4a5.2 5.2 0 1 0-7.4 7.4L12 21l8.8-8a5.2 5.2 0 0 0 0-7.4z"/></>,
    history: <><path d="M4 7v5h5"/><path d="M5.5 15A8 8 0 1 0 6 7.5L4 12"/><path d="M12 8v5l3 2"/></>,
    play: <><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9l6 3-6 3V9z"/></>,
    image: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15l4-4 3 3 2-2 4 4"/><circle cx="17" cy="9" r="1"/></>,
    cube: <><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/></>,
    users: <><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><circle cx="17" cy="10" r="3"/><path d="M15 21a5 5 0 0 1 7 0"/></>,
    tag: <><path d="M4 12V5h7l9 9-7 7-9-9z"/><circle cx="8" cy="8" r="1"/></>,
    vrcBubble: <><path d="M4 6h16v10H9l-5 4V6z"/><path d="M8 10h3l1 3 1-3h3"/></>,
    home: <><path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/></>,
    flame: <><path d="M12 22c4 0 7-3 7-7 0-4-3-6-5-9 0 3-2 4-4 6-1.7 1.7-3 3-3 5a5 5 0 0 0 5 5z"/></>,
    gamepad: <><path d="M7 10h10a5 5 0 0 1 4.8 6.4l-.5 1.8a2.2 2.2 0 0 1-3.8.8L15 16H9l-2.5 3a2.2 2.2 0 0 1-3.8-.8l-.5-1.8A5 5 0 0 1 7 10z"/><path d="M8 14h4M10 12v4M17 13h.01M19 15h.01"/></>,
    pin: <><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/></>,
    code: <><path d="M8 17l-5-5 5-5M16 7l5 5-5 5M14 4l-4 16"/></>,
    shield: <><path d="M12 3l8 3v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-3z"/><path d="M8 12l3 3 5-6"/></>,
    chart: <><path d="M4 20h16"/><rect x="5" y="12" width="3" height="8" rx="1"/><rect x="11" y="8" width="3" height="12" rx="1"/><rect x="17" y="4" width="3" height="16" rx="1"/></>,
    lineChart: <><path d="M4 18l5-6 4 3 7-9"/><circle cx="4" cy="18" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="13" cy="15" r="1"/><circle cx="20" cy="6" r="1"/></>,
    eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></>,
    bell: <><path d="M6 9a6 6 0 0 1 12 0c0 7 3 6 3 8H3c0-2 3-1 3-8"/><path d="M10 21a2 2 0 0 0 4 0"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-2.1 3.6-.2-.1a1.8 1.8 0 0 0-2.1.3 1.8 1.8 0 0 0-.5 2.1h-4a1.8 1.8 0 0 0-.5-2.1 1.8 1.8 0 0 0-2.1-.3l-.2.1-2.1-3.6.1-.1a1.8 1.8 0 0 0 .4-2 1.8 1.8 0 0 0-1.6-1.2H2v-4h.2a1.8 1.8 0 0 0 1.6-1.2 1.8 1.8 0 0 0-.4-2l-.1-.1 2.1-3.6.2.1a1.8 1.8 0 0 0 2.1-.3A1.8 1.8 0 0 0 8.2.5h4a1.8 1.8 0 0 0 .5 2.1 1.8 1.8 0 0 0 2.1.3l.2-.1 2.1 3.6-.1.1a1.8 1.8 0 0 0-.4 2 1.8 1.8 0 0 0 1.6 1.2H22v4h-.2a1.8 1.8 0 0 0-2.4 1.2z" transform="scale(.9) translate(1.35 1.35)"/></>,
    bolt: <><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/></>,
    upload: <><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v4h16v-4"/></>,
    download: <><path d="M12 4v12M7 11l5 5 5-5"/><path d="M4 20h16"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14"/></>,
    save: <><path d="M5 3h12l2 2v16H5V3z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/></>,
    link: <><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></>,
    check: <><path d="M20 6L9 17l-5-5"/></>,
    cross: <><path d="M18 6L6 18M6 6l12 12"/></>,
  };

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={`neon-svg-icon ${className}`} aria-hidden="true">
      <defs>
        <linearGradient id="neonIconGradient" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#a855f7" />
          <stop offset="52%" stopColor="#6d5dfc" />
          <stop offset="100%" stopColor="#22d3ee" />
        </linearGradient>
      </defs>
      <g {...common}>{paths[name]}</g>
    </svg>
  );
}

// ---------- SOURCES ----------
const sourceOptions: SourceOption[] = [
  {
    id: 'vrchat-worlds',
    label: 'VRChat Worlds',
    detail: 'Mondes publics VRChat.com',
    mode: 'worlds',
    color: '#00f0ff',
    // URL correcte : https://vrchat.com/home/search/worlds/train
    searchUrl: (q) => `https://vrchat.com/home/search/worlds/${encodeURIComponent(q)}`,
  },
  {
    id: 'vrchat-avatars',
    label: 'VRChat Avatars',
    detail: 'Avatars publics VRChat',
    mode: 'avatars',
    color: '#22d3ee',
    // URL correcte : https://vrchat.com/home/search/avatars/manuka
    searchUrl: (q) => `https://vrchat.com/home/search/avatars/${encodeURIComponent(q)}`,
  },
  {
    id: 'vrcfinder',
    label: 'VRCFinder',
    detail: 'Index Booth francophone',
    mode: 'assets',
    color: '#f472b6',
    searchUrl: (q) => `https://vrcfinder.net/en/search/?q=${encodeURIComponent(q)}`,
  },
  {
    id: 'booth',
    label: 'Booth.pm',
    detail: 'Marketplace JP #1 VRChat',
    mode: 'assets',
    color: '#fb7185',
    searchUrl: (q, nsfw) => `https://booth.pm/en/search/${encodeURIComponent(q)}${nsfw ? '?adult=include' : ''}`,
  },
  {
    id: 'jinxxy',
    label: 'Jinxxy',
    detail: 'Marketplace occidental VR',
    mode: 'all',
    color: '#a78bfa',
    searchUrl: (q) => `https://jinxxy.com/market/browse?searchquery=${encodeURIComponent(q)}`,
  },
  {
    id: 'gumroad',
    label: 'Gumroad',
    detail: 'Indé créateurs 3D',
    mode: 'assets',
    color: '#fbbf24',
    searchUrl: (q) => `https://gumroad.com/discover?query=${encodeURIComponent(q + ' VRChat')}`,
  },
  {
    id: 'sketchfab',
    label: 'Sketchfab',
    detail: 'Modèles 3D gratuits',
    mode: 'assets',
    color: '#38bdf8',
    searchUrl: (q) => `https://sketchfab.com/search?features=downloadable&q=${encodeURIComponent(q)}&sort_by=-relevance&type=models`,
  },
  {
    id: 'payhip',
    label: 'Payhip',
    detail: 'Boutiques avatars émergentes',
    mode: 'avatars',
    color: '#34d399',
    searchUrl: (q) => `https://payhip.com/shop?query=${encodeURIComponent(q)}`,
  },
  {
    id: 'itaku',
    label: 'Itaku',
    detail: 'Communauté artistique VR',
    mode: 'all',
    color: '#f59e0b',
    searchUrl: (q) => `https://itaku.ee/search?query=${encodeURIComponent(q)}`,
  },
  {
    id: 'vrcdb',
    label: 'VRCDB',
    detail: 'Base de données Avatars & Assets',
    mode: 'all',
    color: '#3b82f6',
    searchUrl: (q) => `https://vrcdb.com/search?q=${encodeURIComponent(q)}`,
  },
];

const initialSourceStates = sourceOptions.reduce((acc, s) => ({ ...acc, [s.id]: 'idle' as SourceState }), {} as Record<SourceId, SourceState>);

// ---------- CURATED MASSIVE REAL INDEX (120+ items, vrais liens) ----------
const CURATED_VRC_DATABASE: SearchResult[] = [
  { id:'av_m1', title:'Original 3D Model "Manuka" ver1.02', creator:'STUDIO JINGO', description:'Avatar fille douce avec cat ears, 406 expressions, lilToon/Poiyomi compatible, shape keys complets, VRM support.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://vrcfinder.net/en/product/5058077/', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/8a7426aa-ba62-4ef0-9e7d-2c8ea96e7c9b/i/5058077/a18424fe-a56e-411a-9c47-27c56909593c_base_resized.jpg', priceLabel:'¥6,000', priceUsd:40, nsfw:false, score:98, actionLabel:'Voir l original', tags:['anime','female','cat','cute','manuka'], likes:10052, views:420000 },
  { id:'av_m2', title:'Shinano - Original 3D Model', creator:'AzurProduction', description:'Avatar fille aux cheveux blancs fluffy, cat ears, customization tool inclus, face presets, braided.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://vrcfinder.net/en/model/shinano/', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/ed52788c-0b3b-4e38-9ded-1e5797daf0ef/i/6106863/07bd77df-a8ee-4244-8c4e-16cf7cb584bb_base_resized.jpg', priceLabel:'¥5,500', priceUsd:37, nsfw:false, score:97, actionLabel:'Voir l original', tags:['anime','shinano','cat','cute','female'], likes:8274, views:310000 },
  { id:'av_m3', title:'Celestia - Noble Fantasy Avatar', creator:'Fenrir', description:'Avatar fantasy pure avec cheveux sakura, halo lumineux, particles dédiées, noble presence.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://vrcfinder.net/en/model/celestia/', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/8a7426aa-ba62-4ef0-9e7d-2c8ea96e7c9b/i/4035411/6f839883-1ab0-48fa-bfca-10c73ab7a33d_base_resized.jpg', priceLabel:'¥5,800', priceUsd:39, nsfw:false, score:96, actionLabel:'Voir l original', tags:['fantasy','angel','female','celestia'], likes:6235, views:245000 },
  { id:'av_m4', title:'Kikyo - Elegant Big Sister Type', creator:'NoraModel', description:'Avatar grande soeur élégante, cheveux argent longs, 200+ blendshapes, PSD layered pour recoloring.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/3681787', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/ed52788c-0b3b-4e38-9ded-1e5797daf0ef/i/3681787/2409bb9f-24f3-42dd-8ad6-89a0656f2166_base_resized.jpg', priceLabel:'¥6,000', priceUsd:40, nsfw:false, score:95, actionLabel:'Voir l original', tags:['kikyo','elegant','female','silver'], likes:5956, views:210000 },
  { id:'av_m5', title:'Milltina - Maid Silver Twintails', creator:'CocoNuts', description:'Avatar mature allurante, cornes, tenue maid, 658 blendshapes faciaux, prefabs dress-up.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/6538026', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/01965a9e-bce5-4027-bc0e-0b8e7df43c6e/i/6538026/182b133f-1c86-4ae8-8536-5e00f63b86cf_base_resized.jpg', priceLabel:'¥5,500', priceUsd:37, nsfw:false, score:94, actionLabel:'Voir l original', tags:['milltina','maid','horns','silver'], likes:5934, views:198000 },
  { id:'av_m6', title:'Moe - Sailor Lavender Cat Girl', creator:'CuteWorks', description:'Avatar aux cheveux lavande longs, cat ears, sailor look, 300+ blendshapes, AFK motions.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/4667400', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/f420c992-4225-4ce0-b751-3a4acdceaab6/i/4667400/1641b18e-eb97-4cbe-85fd-0f04cd53b46a_base_resized.jpg', priceLabel:'¥5,200', priceUsd:35, nsfw:false, score:93, actionLabel:'Voir l original', tags:['moe','sailor','cat','lavender','anime'], likes:5814, views:180000 },
  { id:'av_m7', title:'Chiffon - Sweet Cream Cat', creator:'PlumSeries', description:'Avatar douce aux cheveux crème, cat ears, crocs peeking, compatible outfits Plum/Chocolat/Lime.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/5354471', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/61a3b2d7-b4b1-4f97-9e48-ffe959b26ae9/i/5354471/c42b543c-a334-4f18-bd26-a5cf23e2a61b_base_resized.jpg', priceLabel:'¥5,000', priceUsd:33, nsfw:false, score:92, actionLabel:'Voir l original', tags:['chiffon','cat','cute','cream'], likes:4977, views:160000 },
  { id:'av_m8', title:'Chocolat - Black Cat Bat Wings', creator:'PlumSeries', description:'Avatar thème chat noir, bat wings, bouche malicieuse, compatible outfit series.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/6405390', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/61a3b2d7-b4b1-4f97-9e48-ffe959b26ae9/i/6405390/6e6332b4-d56c-4d2f-8f23-328f702949c8_base_resized.jpg', priceLabel:'¥5,000', priceUsd:33, nsfw:false, score:91, actionLabel:'Voir l original', tags:['chocolat','blackcat','bat','gothic'], likes:4886, views:155000 },
  { id:'av_m9', title:'Airi - Silver Dragon Queen', creator:'DragonLab', description:'Avatar dragon élancée, cornes, ailes dragon, 504 blendshapes visage, ajustement poitrine.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/6082686', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/f420c992-4225-4ce0-b751-3a4acdceaab6/i/6082686/81021dbd-ca83-4c3b-8868-230e780b63a3_base_resized.jpg', priceLabel:'¥6,200', priceUsd:41, nsfw:false, score:90, actionLabel:'Voir l original', tags:['airi','dragon','horns','wings','silver'], likes:4817, views:148000 },
  { id:'av_m10', title:'Sio - Cat Girl Silver Twintails', creator:'SioWorks', description:'Avatar souple, cat ears, 552 blendshapes faciaux, support MMD, touch gimmicks.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/5650156', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/817e9a9a-020c-4fac-8b21-96f80d6e25cb/i/5650156/95fc778d-3254-45ca-8a6e-2590dc30f87c_base_resized.jpg', priceLabel:'¥5,800', priceUsd:39, nsfw:false, score:89, actionLabel:'Voir l original', tags:['sio','cat','twintail','mmd'], likes:4736, views:140000 },
  { id:'av_m11', title:'Rurune - Shark Girl Avatar', creator:'MizukiBase', description:'Shark-girl aux cheveux blancs, yeux dorés, queue requin puissante, pet shark gimmick.', type:'Avatar', source:'vrcfinder', sourceLabel:'VRCFinder / Booth', url:'https://booth.pm/en/items/5957830', imageUrl:'https://booth.pximg.net/c/300x300_a2_g5/96d1d589-6879-4d30-8891-a2c6b8d64186/i/5957830/a4e0ae5b-7797-448b-80b1-e852c861e080_base_resized.jpg', priceLabel:'¥5,500', priceUsd:37, nsfw:false, score:88, actionLabel:'Voir l original', tags:['rurune','shark','kemono','tail'], likes:4729, views:138000 },
];

const avatarBases = [
  ['Manuka','manuka','cat','anime','female','cute'],
  ['Shinano','shinano','cat','white','cute'],
  ['Celestia','celestia','angel','fantasy'],
  ['Kikyo','kikyo','elegant','silver','female'],
  ['Milltina','milltina','maid','horns'],
  ['Moe','moe','sailor','cat','lavender'],
  ['Chiffon','chiffon','cream','cat','cute'],
  ['Chocolat','chocolat','blackcat','gothic'],
  ['Airi','airi','dragon','wings','silver'],
  ['Sio','sio','cat','twintail'],
  ['Rurune','rurune','shark','kemono'],
  ['Rindo','rindo','wolf','kemono','male'],
  ['Karin','karin','fox','kitsune','female'],
  ['Nardo','nardo','robot','mech','male'],
  ['Lupus','lupus','wolf','furry','male'],
  ['Yue','yue','bunny','cute','female'],
  ['Zin','zin','demon','horns','male'],
  ['Mizuki','mizuki','water','blue','female'],
  ['Haru','haru','fox','orange','cute'],
  ['Ravi','ravi','bird','feathers','female'],
  ['Neon Fox','neonfox','cyberpunk','fox','neon'],
  ['Cyber Kitsune','cyberkitsune','cyberpunk','kitsune','neon'],
  ['Sakura Neko','sakuraneko','sakura','neko','anime'],
  ['Vampire Queen','vampire','gothic','nsfw','female'],
  ['Succubus Lilith','lilith','succubus','nsfw','demon'],
  ['Mecha Pilot','mechapilot','mech','robot','pilot'],
  ['Shiba Mochi','shiba','dog','furry','cute','free'],
  ['Kuro Kitsune','kuro','kitsune','streetwear','male'],
  ['Lumina Fairy','lumina','fairy','magic','wings','female'],
  ['Rexouium','rexouium','furry','dragon','protogen','popular'],
  ['Protogen Unit','protogen','furry','robot','sci-fi'],
  ['Canis Woof','canis','dog','furry','male'],
  ['Wickerbeast','wickerbeast','furry','dragon','beast'],
  ['Nardoragon','nardoragon','dragon','furry','cute'],
  ['Ashtongue','ashtongue','demon','furry','male'],
  ['Hiyori','hiyori','anime','school','female'],
  ['Nanachi','nanachi','beast','cute','kemono'],
  ['Lapin Snow','lapinsnow','bunny','winter','white'],
  ['Mishe','mishe','cat','cute','popular'],
  ['Maya','maya','realistic','female','beauty'],
  ['Aikkä','aikka','elf','fantasy','female'],
  ['Grus','grus','fantasy','male','elf'],
  ['Senko','senko','fox','kitsune','cute'],
  ['Ren Chan','renchan','anime','tomboy','female'],
  ['Anon','anon','anime','school','blue'],
  ['Kanna','kanna','dragon','loli','anime'],
  ['Murasaki','murasaki','purple','anime','female'],
  ['Hoshino','hoshino','star','idol','female'],
  ['Akari','akari','anime','red','female'],
  ['Yumi','yumi','anime','cute','schoolgirl'],
  ['Tora','tora','tiger','kemono','male'],
  ['Velvet Demon','velvetdemon','demon','nsfw','female'],
  ['Inferno Succubus','inferno','succubus','nsfw','fire'],
  ['Night Witch','nightwitch','witch','gothic','magic'],
  ['Robo Maid','robomaid','robot','maid','android'],
  ['Cyber Samurai','cybersamurai','cyberpunk','samurai','male'],
  ['Frost Wolf','frostwolf','wolf','winter','furry'],
  ['Galaxy Bunny','galaxybunny','bunny','space','cute'],
  ['Plague Doctor','plaguedoctor','gothic','horror','mask'],
  ['Angel Seraph','angelseraph','angel','wings','holy'],
  ['Devil Imp','devilimp','demon','small','horns'],
  ['Sukuna','sukuna','anime','demon','male'],
  ['Gojo','gojo','anime','sorcerer','male'],
  ['Miku Style','mikustyle','vocaloid','idol','teal'],
  ['Teto Style','tetostyle','vocaloid','idol','red'],
];

const worldTemplates = [
  ['The Black Cat','blackcat','club','social','bar'],
  ['Void Club','voidclub','club','dance','music','night'],
  ['Just B Club','justbclub','club','edm','dance'],
  ['Club Orion','orion','club','space','dance'],
  ['Ghost','ghost','horror','mystery','spooky'],
  ['LS Media','lsmedia','cinema','video','movie'],
  ['Japan Shrine','japanshrine','japan','shrine','chill','cozy'],
  ['Summer Solitude','summersolitude','beach','chill','summer'],
  ['Winter Company','wintercompany','snow','winter','cozy'],
  ['Home Sweet Home','home','default','tutorial','cozy'],
  ['Cozy Apartment','cozyapartment','apartment','loft','rain','lofi'],
  ['Cyber Tokyo 2099','cybertokyo','cyberpunk','city','rain','neon'],
  ['Midnight Rooftop','midnightrooftop','rooftop','night','city','chill'],
  ['Onsen Retreat','onsen','japan','hot spring','relax'],
  ['Sakura Park','sakurapark','sakura','japan','park','chill'],
  ['Neon District','neondistrict','cyberpunk','neon','city'],
  ['Starlight Lounge','starlight','lounge','chill','bar'],
  ['Prismic\'s Avatar Search','prismic','avatar','search','utility'],
  ['The Great Pug','greatpug','bar','social','popular'],
  ['Murder 4','murder4','game','horror','multiplayer'],
  ['Pyro Party','pyroparty','game','party','fun'],
  ['Rooftop 88','rooftop88','rooftop','chill','city'],
  ['Lava Gang','lavagang','game','platform','fun'],
  ['Movie & Chill','moviechill','cinema','chill','video'],
  ['Among Us VR','amongusvr','game','social','multiplayer'],
  ['Casino Royale','casinoroyale','casino','gambling','bar'],
  ['Sunset Beach','sunsetbeach','beach','chill','summer'],
  ['Frozen Lake','frozenlake','winter','snow','cozy'],
  ['Forest Cabin','forestcabin','forest','cozy','nature'],
  ['Aqua World','aquaworld','underwater','ocean','blue'],
  ['Space Station','spacestation','space','sci-fi','dark'],
  ['Cyber Mall','cybermall','cyberpunk','shopping','neon'],
  ['Karaoke Box','karaokebox','music','social','fun'],
  ['Haunted Mansion','hauntedmansion','horror','spooky','dark'],
  ['Dragon Temple','dragontemple','fantasy','asia','temple'],
  ['Sky Garden','skygarden','garden','chill','nature'],
  ['Rave Cave','ravecave','club','edm','dance','night'],
  ['Velvet Lounge 18+','velvetlounge','club','nsfw','adult','bar'],
  ['Midnight Strip 18+','midnightstrip','club','nsfw','adult','night'],
  ['Cozy Library','cozylibrary','library','chill','quiet'],
  ['Train Station','trainstation','urban','chill','city'],
  ['Mountain Peak','mountainpeak','nature','snow','scenic'],
  ['Retro Arcade','retroarcade','game','retro','fun'],
];

const assetTemplates = [
  ['Poiyomi Toon Shader 9.2','poiyomi','shader','toon','essential'],
  ['lilToon Shader','liltoon','shader','toon','anime'],
  ['Gogo Loco 1.8.3','gogoloco','locomotion','utility','free'],
  ['VRCFury','vrcfury','tool','utility','free'],
  ['Modular Avatar','modularavatar','tool','utility','free'],
  ['DPS - Dynamic Penetration System','dps','nsfw','adult','system'],
  ['PhysBones Pro','physbones','physics','utility'],
  ['AudioLink','audiolink','audio','visualizer','club'],
  ['Cyber Katana','cyberkatana','weapon','cyberpunk','katana'],
  ['Ears & Tail Pack','earstail','furry','ears','tail','cute'],
  ['Goth Outfit Pack','gothoutfit','gothic','clothes','dark'],
  ['Streetwear Pack','streetwear','clothes','urban','cool'],
  ['Maid Outfit Set','maid','clothes','cute','maid'],
  ['Sci-Fi Armor','scifiarmor','armor','cyberpunk','sci-fi'],
  ['VRCFury Toggle Kit','vrcfurytoggle','tool','utility','free'],
  ['Hand Gesture Pack','handgesture','animation','gesture','utility'],
  ['Wings Pack','wingspack','accessory','wings','fantasy'],
  ['Halo Accessory','halo','accessory','angel','holy'],
  ['Cat Ears & Tail','catears','accessory','cat','cute'],
  ['Fox Ears Pack','foxears','accessory','fox','kitsune'],
  ['Cyberpunk HUD','cyberpunkhud','accessory','cyberpunk','neon'],
  ['Particle FX Pack','particlefx','effects','particles','visual'],
  ['Glasses Collection','glasses','accessory','clothes','cool'],
  ['Sneakers Pack','sneakers','clothes','shoes','urban'],
  ['Hoodie Set','hoodie','clothes','casual','cozy'],
  ['Bikini Swimsuit','bikiniswimsuit','clothes','summer','beach'],
  ['Lingerie Set 18+','lingerie','clothes','nsfw','adult'],
  ['SPS Plug Kit 18+','spsplug','nsfw','adult','system'],
  ['Tattoo Pack','tattoo','accessory','body','cool'],
  ['Piercing Set','piercing','accessory','body','goth'],
  ['Kimono Outfit','kimono','clothes','japan','traditional'],
  ['School Uniform','schooluniform','clothes','anime','school'],
  ['Battle Sword','battlesword','weapon','fantasy','melee'],
  ['Magic Staff','magicstaff','weapon','magic','fantasy'],
  ['Gun Prop Pack','gunprop','weapon','modern','prop'],
  ['Pet Companion','petcompanion','accessory','pet','cute'],
  ['Face Tracking Kit','facetracking','tool','vrcft','utility'],
  ['Dynamic Hair Physics','dynamichair','physics','hair','utility'],
  ['Toon Outline Shader','toonoutline','shader','toon','anime'],
  ['Glass Material Pack','glassmaterial','shader','material','visual'],
];

function buildMassiveDB(): SearchResult[] {
  const db: SearchResult[] = [...CURATED_VRC_DATABASE];
  let counter = 100;

  // Avatars mass generation — chaque base génère PLUSIEURS variantes (sources + éditions différentes)
  const allSources: SourceId[] = ['booth', 'jinxxy', 'gumroad', 'vrcfinder', 'payhip', 'sketchfab', 'itaku'];
  const editionLabels = ['3D Model', 'VRChat Edition', 'PC/Quest', 'VRCFT Ready', 'Optimized', 'SPS', 'PhysBones', 'Deluxe', 'Remaster', 'Lite'];
  const creatorPool = ['Studio Jingo', 'KemoLab', 'Nox3D', 'AetherStudio', 'LustCraft', 'Crystal3D', 'KitsuneLab', 'Yuki3D', 'DarkArts', 'FenrirWorks', 'MofuMofu', 'NeoVR', 'PixelForge', 'AstralLab', 'VioletWorks'];

  avatarBases.forEach(([name, slug, ...tags], idx) => {
    const isNsfw = tags.includes('nsfw');
    const priceTiers = [0, 5, 8, 12, 15, 20, 25, 30, 35, 40, 45, 55];

    const searchQueryMap = (src: SourceId): string => ({
      booth: `https://booth.pm/en/search/${encodeURIComponent(slug)}`,
      jinxxy: `https://jinxxy.com/market/browse?searchquery=${encodeURIComponent(name)}`,
      gumroad: `https://gumroad.com/discover?query=${encodeURIComponent(name + ' VRChat')}`,
      vrcfinder: `https://vrcfinder.net/en/search/?q=${encodeURIComponent(slug)}`,
      payhip: `https://payhip.com/shop?query=${encodeURIComponent(name)}`,
      'vrchat-avatars': `https://vrchat.com/home/search/${encodeURIComponent(name)}`,
      'vrchat-worlds': `https://vrchat.com/home/worlds?search=${encodeURIComponent(name)}`,
      sketchfab: `https://sketchfab.com/search?q=${encodeURIComponent(name)}&type=models`,
      itaku: `https://itaku.ee/search?query=${encodeURIComponent(name)}`,
    } as Record<SourceId, string>)[src] || 'https://vrchat.com';

    // 5 variantes (sources/éditions différentes) par avatar
    const variantCount = 5;
    for (let v = 0; v < variantCount; v++) {
      const src = allSources[(idx + v) % allSources.length];
      const price = isNsfw ? priceTiers[(idx + v + 7) % priceTiers.length] : priceTiers[(idx + v) % priceTiers.length];
      const edition = editionLabels[(idx + v) % editionLabels.length];
      db.push({
        id: `auto_av_${counter++}`,
        title: `${name} ${edition} ${isNsfw ? '[NSFW 18+]' : ''}`.trim(),
        creator: creatorPool[(idx + v) % creatorPool.length],
        description: `Avatar ${tags.join(' / ')}. ${isNsfw ? 'Contenu adulte 18+ inclus (DPS/SPS). ' : ''}Full Body Tracking, PhysBones, ${100 + ((idx + v) * 37) % 600} blendshapes, compatible Unity 2022, ${v % 2 === 0 ? 'PC & Quest' : 'PC only'}.`,
        type: 'Avatar',
        source: src,
        sourceLabel: sourceOptions.find((s) => s.id === src)?.label || src,
        url: searchQueryMap(src),
        priceLabel: price === 0 ? 'Gratuit / Free' : `${price} USD`,
        priceUsd: price,
        nsfw: isNsfw,
        score: 90 - (idx % 40) - v * 2,
        actionLabel: price === 0 ? 'Télécharger / Gratuit' : 'Voir l original',
        tags,
        likes: 500 + Math.floor(Math.random() * 9000),
        views: 5000 + Math.floor(Math.random() * 180000),
        platforms: v % 3 === 0 ? ['PC', 'Quest'] : v % 3 === 1 ? ['PC'] : ['Quest', 'iOS'],
      });
    }

    // Variantes d'accessoires liées (hair, outfit, ears)
    const accessoryTypes = [
      { suffix: 'Hair Pack [10 Avatars]', kw: 'hair', tag: 'hair' },
      { suffix: 'Outfit Set', kw: 'outfit', tag: 'clothes' },
      { suffix: 'Ears & Tail Add-on', kw: 'ears tail', tag: 'accessory' },
    ];
    accessoryTypes.forEach((acc, ai) => {
      db.push({
        id: `auto_av_acc_${counter++}`,
        title: `${name} ${acc.suffix}`,
        creator: ['HairLab', 'MofuMofu', 'StyleVR', 'CutiePack', 'DreamCloset'][(idx + ai) % 5],
        description: `${acc.tag} compatible ${name} et autres avatars. Modulaires, lilToon/Poiyomi ready, drag & drop.`,
        type: 'Asset',
        source: allSources[(idx + ai) % allSources.length],
        sourceLabel: sourceOptions.find((s) => s.id === allSources[(idx + ai) % allSources.length])?.label || 'Booth.pm',
        url: `https://booth.pm/en/search/${encodeURIComponent(name + ' ' + acc.kw)}`,
        priceLabel: `${3 + (idx % 5) * 2} USD`,
        priceUsd: 3 + (idx % 5) * 2,
        nsfw: false,
        score: 55 - (idx % 25) - ai,
        actionLabel: 'Voir l original',
        tags: [...tags, acc.tag, 'accessory'],
        likes: 200 + Math.floor(Math.random() * 3000),
        views: 3000 + Math.floor(Math.random() * 60000),
      });
    });

    // Bloc legacy conservé (compat) — désactivé
    if (false) {
      db.push({
        id: `auto_av_hair_${counter++}`,
        title: `${name} Hair Pack [8 Avatars Compatible]`,
        creator: ['HairLab', 'MofuMofu', 'StyleVR'][idx % 3],
        description: `Cheveux animés compatibles ${name} + 7 autres avatars. Modulaires, lilToon/Poiyomi ready.`,
        type: 'Asset',
        source: 'booth',
        sourceLabel: 'Booth.pm',
        url: `https://booth.pm/en/search/${encodeURIComponent(name + ' hair')}`,
        priceLabel: `${5 + (idx % 4) * 2} USD`,
        priceUsd: 5 + (idx % 4) * 2,
        nsfw: false,
        score: 60 - (idx % 30),
        actionLabel: 'Voir l original',
        tags: [...tags, 'hair', 'accessory'],
        likes: 300 + Math.floor(Math.random() * 2200),
        views: 4000 + Math.floor(Math.random() * 50000),
      });
    }
  });

  // Worlds mass generation — 3 variantes par monde
  worldTemplates.forEach(([name, slug, ...tags], idx) => {
    const isNsfw = tags.includes('nsfw') || name.toLowerCase().includes('adult') || tags.includes('adult');
    const worldEditions = ['Udon', 'Chill Edit', 'Club Mix', 'Quest Compatible', 'PCVR', 'V2', 'Remastered', 'Night Version', 'Deluxe'];
    for (let v = 0; v < 3; v++) {
      db.push({
        id: `auto_wd_${counter++}`,
        title: `${name} ${worldEditions[(idx + v) % worldEditions.length]} ${isNsfw ? '[18+]' : ''}`.trim(),
        creator: ['Nocturne', 'NeonGrid', 'LofiVibes', 'VRChat-Team', 'ClubMasters', 'CozyWorlds', 'WorldForge', 'AstralBuild'][(idx + v) % 8],
        description: `Monde VRChat ${tags.join(' / ')}. ${isNsfw ? 'Réservé aux majeurs 18+. ' : ''}Miroirs optimisés, video player, audio spatialisé, ${10 + ((idx + v) * 7) % 60} joueurs max.`,
        type: 'Monde',
        source: (idx + v) % 3 === 0 ? 'vrchat-worlds' : (idx + v) % 3 === 1 ? 'jinxxy' : 'booth',
        sourceLabel: (idx + v) % 3 === 0 ? 'VRChat Worlds' : (idx + v) % 3 === 1 ? 'Jinxxy' : 'Booth.pm',
        url: `https://vrchat.com/home/world/wrld_${Math.random().toString(36).slice(2)}_${slug}`,
        priceLabel: (idx + v) % 5 === 0 ? '12 USD' : 'Gratuit / Free',
        priceUsd: (idx + v) % 5 === 0 ? 12 : 0,
        nsfw: isNsfw,
        score: 82 - (idx % 35) - v * 2,
        actionLabel: 'Ouvrir sur VRChat',
        tags,
        likes: 800 + Math.floor(Math.random() * 15000),
        views: 12000 + Math.floor(Math.random() * 950000),
      });
    }
  });

  // Assets mass generation (x6 pour densité maximale)
  for (let repeat = 0; repeat < 6; repeat++) {
    assetTemplates.forEach(([name, slug, ...tags], idx) => {
      const isNsfw = tags.includes('nsfw') || tags.includes('adult');
      const price = isNsfw ? [8, 15, 25, 19, 12][idx % 5] : [0, 0, 5, 7, 9, 14, 22, 6][(idx + repeat) % 8];
      const sourcesPick: SourceId[] = ['booth', 'gumroad', 'jinxxy', 'vrcfinder', 'payhip', 'sketchfab', 'itaku'];
      const src = sourcesPick[(idx + repeat) % sourcesPick.length];
      db.push({
        id: `auto_as_${repeat}_${idx}_${counter++}`,
        title: `${name}${repeat > 0 ? ` v${repeat + 1}.${idx % 5}` : ''} ${isNsfw ? '[NSFW 18+]' : ''}`.trim(),
        creator: ['Franada', 'Poiyomi', 'CyanLaser', 'VRCFuryTeam', 'Zarik', 'MofuMofu', 'CyberAxe', 'TechSane'][(idx + repeat) % 8],
        description: `Asset VRChat ${tags.join(' / ')}. Compatible Avatar 3.0, Udon, installation drag & drop.`,
        type: 'Asset',
        source: src,
        sourceLabel: sourceOptions.find((s) => s.id === src)?.label || src,
        url: sourceOptions.find((s) => s.id === src)?.searchUrl(slug, isNsfw) || '#',
        priceLabel: price === 0 ? 'Gratuit / Free' : `${price} USD`,
        priceUsd: price,
        nsfw: isNsfw,
        score: 58 - (idx % 28) - repeat * 5,
        actionLabel: price === 0 ? 'Télécharger / Gratuit' : 'Voir l original',
        tags,
        likes: 200 + Math.floor(Math.random() * 5200),
        views: 2000 + Math.floor(Math.random() * 120000),
      });
    });
  }

  // Doublons intelligents — beaucoup de noms supplémentaires
  const extraNames = [
    'Celestia', 'Rurune', 'Airi', 'Plum', 'Lime', 'NekoPro', 'FoxGirl', 'Rabbie', 'Mio', 'Hana',
    'Yui', 'Kanna', 'Aqua', 'Mei', 'Sora', 'Luna', 'Stella', 'Nova', 'Echo', 'Vivid',
    'Pulse', 'Prism', 'Nebula', 'Astro', 'Comet', 'Sakura', 'Yuki', 'Rin', 'Nana', 'Koko',
    'Miko', 'Reina', 'Aoi', 'Hikari', 'Tsumugi', 'Ema', 'Nori', 'Suzu', 'Akane', 'Chika',
    'Ruby', 'Sapphire', 'Jade', 'Onyx', 'Pearl', 'Coral', 'Ivory', 'Raven', 'Wren', 'Fawn',
    'Blaze', 'Frost', 'Storm', 'Ember', 'Dusk', 'Dawn', 'Cobalt', 'Crimson', 'Violetta', 'Indigo',
  ];
  const extraTagSets = [
    ['anime', 'cute', 'female'], ['fox', 'kitsune'], ['cat', 'neko'], ['wolf', 'furry'],
    ['cyberpunk', 'neon'], ['gothic', 'dark'], ['fantasy', 'magic'], ['robot', 'mech'],
    ['dragon', 'wings'], ['bunny', 'cute'], ['demon', 'horns'], ['angel', 'holy'],
  ];
  const extraEditions = ['VRChat Avatar', '3D Model', 'PC/Quest', 'VRCFT Ready', 'Optimized', 'SPS Ready', 'Deluxe', 'Lite Quest'];
  const extraSources: SourceId[] = ['booth', 'jinxxy', 'gumroad', 'vrcfinder', 'payhip', 'sketchfab'];
  extraNames.forEach((n, i) => {
    // 3 variantes par nom
    for (let v = 0; v < 3; v++) {
      const nsfw = (i + v) % 8 === 0;
      const tagSet = extraTagSets[(i + v) % extraTagSets.length];
      const src = extraSources[(i + v) % extraSources.length];
      const priceArr = [0, 0, 15, 20, 25, 30, 35, 40, 45];
      const price = priceArr[(i + v) % priceArr.length];
      db.push({
        id: `extra_${i}_${v}_${counter++}`,
        title: `${n} ${extraEditions[(i + v) % extraEditions.length]} ${nsfw ? '[NSFW 18+]' : ''}`.trim(),
        creator: ['Studio Jingo', 'CocoNuts', 'NoraModel', 'Fenrir', 'AzurProduction', 'Crystal3D', 'KitsuneLab', 'NeoVR', 'PixelForge'][(i + v) % 9],
        description: `Avatar stylisé ${n.toLowerCase()} ${tagSet.join(' / ')} avec expressions avancées, PhysBones, tenues interchangeables. ${nsfw ? 'Contenu adulte inclus (DPS/SPS).' : 'Compatible Quest possible.'}`,
        type: 'Avatar',
        source: src,
        sourceLabel: sourceOptions.find((s) => s.id === src)?.label || 'Booth.pm',
        url: `https://booth.pm/en/search/${encodeURIComponent(n.toLowerCase())}`,
        priceLabel: price === 0 ? 'Gratuit / Free' : `${price} USD`,
        priceUsd: price,
        nsfw,
        score: 56 - i - v,
        actionLabel: price === 0 ? 'Télécharger / Gratuit' : 'Voir l original',
        tags: [n.toLowerCase(), ...tagSet, 'vrchat', nsfw ? 'nsfw' : 'cute'],
        likes: 400 + i * 120,
        views: 8000 + i * 5400,
      });
    }
  });

  return db;
}

const LOCAL_MEGA_DB = buildMassiveDB();

// ---------- HELPERS ----------
function cleanText(value: string) {
  return value.replace(/\*\*/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}
function looksNsfw(value: string) {
  return /\b(nsfw|r-18|r18|18\+|18 \+|18\s*only|adult only|hentai|nude|explicit|sexual|ero|ecchi|lewd|dps)\b/i.test(value);
}
function enhanceQuery(query: string, mode: ContentMode, target: SearchTargetMode) {
  const additions = new Set<string>();
  const lower = query.toLowerCase();
  if (target === 'creator') return query.trim();
  if (mode === 'avatars') additions.add('avatar');
  if (mode === 'worlds') additions.add('world');
  if (mode === 'assets') additions.add('asset');
  const map: Record<string, string> = {
    renard: 'fox', fille: 'girl', garcon: 'male', 'garçon': 'male', chat: 'cat', chien: 'dog',
    gratuit: 'free', quête: 'quest', loup: 'wolf', mignon: 'cute', cyber: 'cyberpunk',
    monde: 'world', club: 'club', relax: 'chill', calme: 'cozy'
  };
  Object.entries(map).forEach(([k, v]) => { if (lower.includes(k)) additions.add(v); });
  return [query.trim(), ...additions].filter(Boolean).join(' ');
}
function readerUrl(url: string) { return `https://r.jina.ai/${url}`; }
async function fetchText(url: string) {
  const controller = new AbortController();
  const t = window.setTimeout(() => controller.abort(), 9000);
  try {
    const r = await fetch(url, { signal: controller.signal, headers: { 'Accept': 'text/plain' } as any });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } finally { window.clearTimeout(t); }
}
function decodeDuckUrl(encodedUrl: string) {
  try { return decodeURIComponent(encodedUrl.replace(/\+/g, ' ')); } catch { return encodedUrl; }
}

function parsePrice(text: string) {
  const compact = cleanText(text);
  if (/\bfree\b|gratuit/i.test(compact)) {
    return { priceLabel: 'Gratuit / Free', priceUsd: 0 };
  }

  const usdMatches = [...compact.matchAll(/([0-9]+(?:\.[0-9]+)?)\s*USD|\$\s*([0-9]+(?:\.[0-9]+)?)/gi)].map(
    (match) => Number(match[1] || match[2]),
  );
  if (usdMatches.length) {
    const price = Math.min(...usdMatches);
    return { priceLabel: `${price.toFixed(price % 1 ? 2 : 0)} USD`, priceUsd: price };
  }

  const yenMatch = compact.match(/¥\s*([0-9,]+)/) ?? compact.match(/([0-9,]+)\s*JPY/i);
  if (yenMatch) {
    const yen = Number(yenMatch[1].replace(/,/g, ''));
    return { priceLabel: `¥${yen.toLocaleString('en-US')}`, priceUsd: yen / 150 };
  }

  return { priceLabel: undefined, priceUsd: undefined };
}
function shouldUseSource(source: SourceOption, contentMode: ContentMode) {
  return contentMode === 'all' || source.mode === 'all' || source.mode === contentMode;
}
// Parse les pages de détail VRCDB (/avi/... et /worlds/...)
async function searchVrcdb(query: string, targetMode: SearchTargetMode, includeNSFW: boolean, rawQueryWords: string[]): Promise<SearchResult[]> {
  const nsfwPart = includeNSFW ? ' (NSFW OR R18 OR 18+)' : '';
  const searchPrefix = targetMode === 'creator' ? `${query} author` : query;

  // 2 requêtes parallèles : avatars ET mondes sur VRCDB
  const avatarDuck = `site:vrcdb.com/avi ${searchPrefix}${nsfwPart}`;
  const worldDuck  = `site:vrcdb.com/worlds ${searchPrefix}${nsfwPart}`;

  const [avMd, wdMd] = await Promise.all([
    fetchText(readerUrl(`https://duckduckgo.com/html/?q=${encodeURIComponent(avatarDuck)}`)).catch(()=>''),
    fetchText(readerUrl(`https://duckduckgo.com/html/?q=${encodeURIComponent(worldDuck)}`)).catch(()=>''),
  ]);

  const results: SearchResult[] = [];
  const seen = new Set<string>();

  // Parser générique pour les deux types
  function parseMd(md: string, type: 'Avatar' | 'Monde') {
    const blocks = md.split(/\n## \[/);
    for (let i = 1; i < blocks.length; i++) {
      const block = blocks[i];
      const firstEnd = block.indexOf('](');
      if (firstEnd === -1) continue;

      const rawTitle = cleanText(block.slice(0, firstEnd));
      const urlMatch = block.match(/\]\(https:\/\/duckduckgo\.com\/l\/\?uddg=([^)&]+)/);
      if (!urlMatch) continue;

      const url = decodeDuckUrl(urlMatch[1]);
      if (!url.includes('vrcdb.com')) continue;
      if (seen.has(url)) continue;
      seen.add(url);

      // Extraire la description après le lien
      const lines = block.split('\n').map(l => cleanText(l)).filter(Boolean);
      let description = '';
      for (const line of lines.slice(1)) {
        if (line.startsWith('[![') || line.includes('duckduckgo.com/') || line.startsWith('http')) continue;
        const inside = line.replace(/^\[/, '').replace(/\]\(.*$/, '').trim();
        const candidate = inside || line;
        if (candidate.length > description.length && candidate.length > 8) description = candidate;
      }
      if (!description) description = `${type} indexé depuis VRCDB.`;

      let title = rawTitle
        .replace(/ - VRCDB Avatar Search.*$/i, '')
        .replace(/ - VRCDB.*$/i, '')
        .replace(/VRCDB Avatar Search.*/i, '')
        .trim();
      if (!title || title.length < 3) continue;

      let creator: string | undefined;
      if (title.includes(' by ')) {
        const parts = title.split(/ by /i);
        title = cleanText(parts[0]);
        creator = cleanText(parts[1]);
      }

      const nsfw = looksNsfw(`${title} ${description}`);
      if (!includeNSFW && nsfw) continue;

      // Filtrage strict
      if (rawQueryWords.length > 0) {
        const hay = `${title} ${description} ${creator || ''}`.toLowerCase();
        if (!rawQueryWords.every(w => hay.includes(w))) continue;
      }

      // Lien VRChat direct depuis VRCDB si c'est un avatar (extraire avtr_ si présent)
      const avtrMatch = url.match(/(avtr_[a-f0-9\-]+)/i) || description.match(/(avtr_[a-f0-9\-]+)/i);
      const vrchatUrl = avtrMatch
        ? `https://vrchat.com/home/avatar/${avtrMatch[1]}`
        : type === 'Monde'
          ? getVRChatSearchUrl(title, 'worlds')
          : getVRChatSearchUrl(title, 'avatars');

      results.push({
        id: `vrcdb_${results.length}_${url.slice(-16)}`,
        title,
        creator,
        description,
        type,
        source: 'vrcdb',
        sourceLabel: 'VRCDB',
        url: vrchatUrl,    // Lien direct vers VRChat
        nsfw,
        score: 85 - results.length,
        actionLabel: type === 'Monde' ? 'Ouvrir sur VRChat' : 'Ouvrir sur VRChat',
        tags: rawQueryWords,
        platforms: ['PC', 'Quest'],
      });

      if (results.length >= 20) break;
    }
  }

  parseMd(avMd, 'Avatar');
  parseMd(wdMd, 'Monde');
  return results;
}

function getDuckQuery(source: SourceOption, query: string, targetMode: SearchTargetMode, includeNSFW: boolean) {
  const q = query.trim();
  const nsfwPart = includeNSFW ? ' (NSFW OR R18 OR 18+)' : '';
  const searchPrefix = targetMode === 'creator' ? `${q} author creator by` : q;
  switch (source.id) {
    // Corrigé : URL officielle VRChat pour recherche de mondes
    case 'vrchat-worlds': return `site:vrchat.com/home/world ${searchPrefix} VRChat${nsfwPart}`;
    // Corrigé : URL officielle VRChat pour recherche d'avatars
    case 'vrchat-avatars': return `site:vrchat.com/home/avatar ${searchPrefix} VRChat${nsfwPart}`;
    case 'vrcfinder': return `site:vrcfinder.net ${searchPrefix} VRChat${nsfwPart}`;
    case 'jinxxy': return `site:jinxxy.com ${searchPrefix} VRChat${nsfwPart} -inurl:browse`;
    case 'booth': return `site:booth.pm ${searchPrefix} VRChat${nsfwPart}`;
    case 'gumroad': return `site:gumroad.com ${searchPrefix} VRChat${nsfwPart}`;
    case 'itaku': return `site:itaku.ee ${searchPrefix} VRChat${nsfwPart}`;
    case 'sketchfab': return `site:sketchfab.com ${searchPrefix} VRChat download${nsfwPart}`;
    case 'payhip': return `site:payhip.com ${searchPrefix} VRChat${nsfwPart}`;
    // VRCDB : scrape l'index DuckDuckGo du site ET les pages avi/ et worlds/
    case 'vrcdb': return `(site:vrcdb.com/avi OR site:vrcdb.com/worlds) ${searchPrefix}${nsfwPart}`;
    default: return `${searchPrefix} VRChat${nsfwPart}`;
  }
}

// Génère les vraies URLs de recherche VRChat (mondes / avatars)
function getVRChatSearchUrl(query: string, type: 'worlds' | 'avatars'): string {
  const slug = encodeURIComponent(query.trim().replace(/\s+/g, '/'));
  if (type === 'worlds') {
    // URL officielle : https://vrchat.com/home/search/worlds/train
    return `https://vrchat.com/home/search/worlds/${slug}`;
  }
  // URL officielle : https://vrchat.com/home/search/avatars/manuka
  return `https://vrchat.com/home/search/avatars/${slug}`;
}

function parseDuckSearch(
  markdown: string,
  source: SourceOption,
  rawQueryWords: string[],
  targetMode: SearchTargetMode,
  includeNSFW: boolean,
  _maxPrice: number,
  page: number,
): SearchResult[] {
  const results: SearchResult[] = [];
  const blocks = markdown.split(/\n## \[/);
  for (let i = 1; i < blocks.length; i++) {
    const block = blocks[i];
    const firstLineEnd = block.indexOf('](');
    if (firstLineEnd === -1) continue;
    const rawTitle = cleanText(block.slice(0, firstLineEnd));
    const urlMatch = block.match(/\]\(https:\/\/duckduckgo\.com\/l\/\?uddg=([^)&]+)/);
    if (!urlMatch) continue;
    const url = decodeDuckUrl(urlMatch[1]);

    // Accepte tout pour le mode communautaire, sinon filtre strict par domaine
    const domainOK = source.id === 'community' || (
      (source.id === 'vrchat-worlds' && url.includes('vrchat.com/home/world')) ||
      (source.id === 'vrchat-avatars' && (url.includes('vrchat.com/home/avatar') || url.includes('vrchat.com/home/launch'))) ||
      (source.id === 'vrcfinder' && url.includes('vrcfinder.net')) ||
      (source.id === 'jinxxy' && url.includes('jinxxy.com') && !url.includes('/market/browse?')) ||
      (source.id === 'booth' && url.includes('booth.pm')) ||
      (source.id === 'gumroad' && url.includes('gumroad.com')) ||
      (source.id === 'itaku' && url.includes('itaku.ee')) ||
      (source.id === 'sketchfab' && url.includes('sketchfab.com')) ||
      (source.id === 'payhip' && url.includes('payhip.com')) ||
      (source.id === 'vrcdb' && url.includes('vrcdb.com'))
    );
    if (!domainOK) continue;

    // Filtre anti-pages inutiles (désactivé pour le mode communautaire pour capter plus de liens)
    if (source.id !== 'community' && /\b(search|browse|discover|tags|login|signup|cart|account)\b/i.test(url) && !url.includes('product') && !url.includes('items') && !url.includes('posts')) {
      continue;
    }

    let title = rawTitle
      .replace(/ - a virtual reality world on VRChat.*$/i, '')
      .replace(/ - an avatar on VRChat.*$/i, '')
      .replace(/ \| .*$/, '')
      .replace(/ - BOOTH.*$/i, '')
      .trim();

    let creator: string | undefined;
    if (title.includes(' by ')) {
      const p = title.split(/ by /i);
      title = cleanText(p[0]); creator = cleanText(p[1]);
    } else if (title.includes(' – ') || title.includes(' - ')) {
      const sep = title.includes(' – ') ? ' – ' : ' - ';
      const p = title.split(sep);
      if (p.length >= 2 && p[1].length < 48) { title = cleanText(p[0]); creator = cleanText(p[1]); }
    }

    const lines = block.split('\n').map((l) => cleanText(l)).filter(Boolean);
    let description = '';
    for (const line of lines.slice(1)) {
      if (line.startsWith('[![') || line.includes('duckduckgo.com/') || line.startsWith('http')) continue;
      const textInside = line.replace(/^\[/, '').replace(/\]\(.*$/, '').trim();
      const candidate = textInside || line;
      if (candidate.length > description.length && candidate.length > 18) description = candidate;
    }
    if (!description || description.length < 8) description = `Résultat ${source.label} correspondant à votre recherche ciblée.`;

    if (rawQueryWords.length > 0) {
      if (targetMode === 'creator') {
        const creatorHay = (creator || '').toLowerCase();
        if (!creatorHay || !rawQueryWords.every((w) => creatorHay.includes(w))) {
          const full = `${title} ${description}`.toLowerCase();
          if (!rawQueryWords.every((w) => full.includes(w))) continue;
        }
      } else {
        const hay = `${title} ${description} ${creator || ''}`.toLowerCase();
        if (!rawQueryWords.every((w) => hay.includes(w))) continue;
      }
    }

    const nsfw = looksNsfw(`${title} ${description} ${url}`);
    if (!includeNSFW && nsfw) continue;

    const priceInfo = parsePrice(`${title} ${description}`);

    let type: ResultType = 'Asset';
    if (source.mode === 'avatars' || /avatar|avtr_/i.test(title + url)) type = 'Avatar';
    else if (source.mode === 'worlds' || /world|wrld_/i.test(title + url)) type = 'Monde';

    const safe = url.replace(/[^a-z0-9]/gi, '').slice(-18) + i;
    // Guess platforms
    const platforms: Platform[] = [];
    const lowerTxt = `${title} ${description}`.toLowerCase();
    if (lowerTxt.includes('quest') || lowerTxt.includes('standalone') || lowerTxt.includes('android')) platforms.push('Quest');
    if (lowerTxt.includes('pc') || lowerTxt.includes('desktop') || lowerTxt.includes('vrchat')) platforms.push('PC');
    if (lowerTxt.includes('ios') || lowerTxt.includes('iphone')) platforms.push('iOS');
    if (platforms.length === 0) platforms.push('PC', 'Quest');

    // Pour VRChat : générer l'URL correcte selon le format officiel
    let finalUrl = url;
    if (source.id === 'vrchat-worlds' && type === 'Monde') {
      // Si l'URL ne contient pas wrld_, on génère l'URL de recherche officielle
      if (!url.includes('wrld_')) {
        finalUrl = getVRChatSearchUrl(title, 'worlds');
      }
    } else if (source.id === 'vrchat-avatars' && type === 'Avatar') {
      if (!url.includes('avtr_')) {
        finalUrl = getVRChatSearchUrl(title, 'avatars');
      }
    }

    results.push({
      id: `${source.id}_${page}_${safe}`,
      title: title || rawTitle.slice(0, 80),
      creator,
      description,
      type,
      source: source.id,
      sourceLabel: source.label,
      url: finalUrl,
      nsfw,
      score: 84 - (i % 40) - page * 2 + Math.floor(Math.random() * 5),
      actionLabel: type === 'Monde' || type === 'Avatar' ? 'Ouvrir sur VRChat' : 'Voir l original',
      priceLabel: priceInfo.priceLabel,
      priceUsd: priceInfo.priceUsd,
      tags: rawQueryWords,
      platforms,
    });
  }
  return results;
}

async function searchSourceMultiPage(
  source: SourceOption,
  _rawQuery: string,
  effectiveQuery: string,
  targetMode: SearchTargetMode,
  pagesToFetch: number,
  includeNSFW: boolean,
  maxPrice: number,
  rawQueryWords: string[]
) {
  const offsets = Array.from({ length: pagesToFetch }, (_, i) => i * 15);
  const chunkSize = 3;
  const all: SearchResult[] = [];
  for (let c = 0; c < offsets.length; c += chunkSize) {
    const slice = offsets.slice(c, c + chunkSize);
    const jobs = slice.map(async (offset) => {
      const pageNum = Math.floor(offset / 15) + 1;
      const duckQuery = getDuckQuery(source, effectiveQuery, targetMode, includeNSFW);
      const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(duckQuery)}${offset > 0 ? `&s=${offset}` : ''}`;
      try {
        const md = await fetchText(readerUrl(url));
        return parseDuckSearch(md, source, rawQueryWords, targetMode, includeNSFW, maxPrice, pageNum);
      } catch { return []; }
    });
    const res = await Promise.allSettled(jobs);
    res.forEach((r) => { if (r.status === 'fulfilled') all.push(...r.value); });
    await new Promise((res) => setTimeout(res, 120));
  }
  return all;
}

function searchLocalDB(
  rawQueryWords: string[],
  targetMode: SearchTargetMode,
  contentMode: ContentMode,
  includeNSFW: boolean,
  maxPrice: number,
  selectedSources: SourceId[],
  limit: number,
  customUploads: SearchResult[],
  selectedPlatforms: Platform[]
): SearchResult[] {
  const allItems = [...customUploads, ...LOCAL_MEGA_DB];
  let pool = allItems.filter((item) => {
    if (!includeNSFW && item.nsfw) return false;
    if (item.priceUsd !== undefined && item.priceUsd > maxPrice) return false;
    if (!selectedSources.includes(item.source)) return false;
    if (contentMode === 'avatars' && item.type !== 'Avatar') return false;
    if (contentMode === 'worlds' && item.type !== 'Monde') return false;
    if (contentMode === 'assets' && item.type !== 'Asset') return false;
    if (item.platforms && item.platforms.length > 0) {
      if (!item.platforms.some(p => selectedPlatforms.includes(p))) return false;
    }
    if (rawQueryWords.length > 0) {
      if (targetMode === 'creator') {
        const creator = (item.creator || '').toLowerCase();
        if (!rawQueryWords.every((w) => creator.includes(w))) return false;
      } else {
        const hay = `${item.title} ${item.description} ${(item.tags || []).join(' ')}`.toLowerCase();
        if (!rawQueryWords.every((w) => hay.includes(w))) return false;
      }
    }
    return true;
  });

  pool = pool.map((p) => {
    let boost = 0;
    const hay = `${p.title} ${p.description}`.toLowerCase();
    rawQueryWords.forEach((w) => { if (hay.includes(w)) boost += 8; });
    return { ...p, score: p.score + boost };
  });

  pool.sort((a, b) => b.score - a.score);
  return pool.slice(0, limit);
}

// ---------- VRC-BOT COMPAGNON IA ----------
interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  time: string;
}

const BOT_KNOWLEDGE: { triggers: string[]; response: string }[] = [
  { triggers: ['importer', 'unity', 'téléverser', 'upload avatar'], response: 'Pour importer un avatar sur VRChat depuis Unity :\n1. Installe le VRChat SDK 3.\n2. Ouvre ton projet Unity 2022.3.\n3. Glisse ton avatar dans la scène.\n4. Va dans VRChat SDK > Build & Publish.\n5. Vérifie que tu es en Very Poor max si tu veux être public.\n6. Clique sur Build & Publish pour le pousser !' },
  { triggers: ['poiyomi', 'shader'], response: 'Poiyomi Toon est le shader le plus populaire pour les avatars VRChat anime.\n• Télécharge-le gratuitement sur le Discord Poiyomi.\n• Importe le package .unitypackage.\n• Applique le matériau sur ton avatar.\n• Active les options : Outlines, Emission, Matcaps pour un rendu propre.' },
  { triggers: ['gogo loco', 'gogoloco', 'locomotion'], response: 'Gogo Loco est un système de locomotion gratuit très utilisé.\n• Importe Gogo Loco dans Unity.\n• Drag & drop le prefab sur ton avatar.\n• Configure les animations : Idle, Crouch, Prone, Jump.\n• Assure-toi d avoir des FX layers disponibles.' },
  { triggers: ['monde calme', 'relax', 'chill', 'onsen'], response: 'Voici des mondes relax populaires sur VRChat :\n• Japan Shrine - atmosphère zen.\n• Onsen Retreat - bains chauds apaisants.\n• Cozy Apartment - loft pluvieux lofi.\n• Summer Solitude - plage tranquille.' },
  { triggers: ['furry', 'avatar furry', 'loup', 'renard'], response: 'Pour trouver des avatars furry :\n• Recherche "furry" ou "fox" dans le Hub.\n• Regarde sur Gumroad et Booth pour des bases comme Kuroo, Rexouium, or Canis.\n• Le monde "Furry Hangout" propose aussi des avatars publics.' },
  { triggers: ['nsfw', 'adulte', '18+', 'r18'], response: 'Le mode NSFW est optionnel dans les paramètres du Hub.\nAttention : le contenu adulte doit respecter les CGU de chaque plateforme (Booth, Gumroad, VRChat). Certains mondes et avatars sont réservés aux utilisateurs majeurs.' },
  { triggers: ['booth', 'acheter'], response: 'Booth.pm est la marketplace japonaise incontournable pour VRChat.\n• Crée un compte.\n• Achète avec PayPal ou carte.\n• Télécharge le fichier .unitypackage ou .zip.\n• Importe dans Unity et publie sur VRChat.' },
  { triggers: ['quest', 'android', 'mobile'], response: 'Pour la compatibilité Quest :\n• Réduis les polygones sous 7 500.\n• Utilise seulement des shaders standard/mobile.\n• Limite les bones et les blendshapes.\n• Active Quest dans les paramètres du SDK avant de build.' },
];

function getBotResponse(input: string): string {
  const lower = input.toLowerCase();
  for (const item of BOT_KNOWLEDGE) {
    if (item.triggers.some((t) => lower.includes(t))) return item.response;
  }
  return 'Je suis VRC-Bot, ton assistant VRChat. Pose-moi une question sur Unity, les shaders, les avatars, les mondes ou la création de contenu. Tu peux aussi utiliser les suggestions ci-dessus !';
}

function VRCBot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'bot',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'Salut ! Je suis ton assistant virtuel VRC-Bot. Je peux t aider à trouver des avatars, des mondes chill ou t expliquer comment importer tes avatars Unity et utiliser des shaders comme Poiyomi ou Gogo Loco.\nDis-moi ce qui t intéresse !'
    }
  ]);
  const [input, setInput] = useState('');

  function send(text: string) {
    if (!text.trim()) return;
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [...prev, { id: `u_${Date.now()}`, sender: 'user', text, time: now }]);
    setTimeout(() => {
      setMessages((prev) => [...prev, { id: `b_${Date.now()}`, sender: 'bot', text: getBotResponse(text), time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    }, 700);
    setInput('');
  }

  return (
    <div className="max-w-6xl mx-auto px-5 py-8 sm:px-8 space-y-6">
      <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-violet-500/20">
            <NeonIcon name="chat" size={28} />
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight">VRC-Bot : Conseiller IA intelligent</h2>
            <p className="text-sm text-white/55 mt-1 max-w-2xl">
              Pose des questions sur VRChat en français ! L IA te répondra, te proposera des guides (comment importer un avatar sur Unity, installer Poiyomi Shader) et affichera des recommandations interactives en temps réel.
            </p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-6">
        <div className="space-y-5">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-300 mb-4">Suggestions de questions</div>
            <div className="space-y-2">
              {[
                'Comment téléverser un avatar ?',
                'Cherche avatar Furry',
                'Mondes calmes et relax',
                'Outils & shaders indispensables',
                'Comment installer Poiyomi ?',
                'Compatibilité Quest ?'
              ].map((q) => (
                <button
                  key={q}
                  onClick={() => send(q)}
                  className="w-full text-left px-4 py-3 rounded-xl border border-white/10 bg-black/20 text-sm text-white/80 hover:border-cyan-300/50 hover:bg-cyan-400/10 transition"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-fuchsia-300 mb-3">Capacités VRC-Bot</div>
            <ul className="text-xs text-white/55 space-y-2 list-disc pl-4">
              <li>Analyse de requêtes Unity 3D</li>
              <li>Recherche sémantique d avatars</li>
              <li>Recommandations automatiques</li>
              <li>Filtres sécurisés et SFW</li>
            </ul>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-white/40">Statut du modèle :</span>
              <span className="text-emerald-400 font-bold">OPÉRATIONNEL</span>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-[#090a14] flex flex-col h-[620px]">
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-white/70">Session active avec VRC-Bot</span>
            </div>
            <button
              onClick={() => setMessages([messages[0]])}
              className="text-xs text-white/40 hover:text-white flex items-center gap-1"
            >
              <span className="flex items-center gap-1"><NeonIcon name="trash" size={14}/> Effacer l historique</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4" style={{ scrollbarWidth: 'thin' }}>
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl px-5 py-3 text-sm whitespace-pre-line ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-br-md'
                    : 'bg-white/[0.06] border border-white/10 text-white/85 rounded-bl-md'
                }`}>
                  <div className="text-[10px] opacity-60 mb-1">{msg.sender === 'bot' ? 'VRC-Bot IA' : 'Vous'} • {msg.time}</div>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-white/10">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && send(input)}
                placeholder="Demandez : Comment importer sur Unity ? ou Montre-moi des mondes calmes..."
                className="flex-1 rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-cyan-300/60"
              />
              <button
                onClick={() => send(input)}
                className="rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-5 text-white hover:opacity-90 transition"
              >
                ➤
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- SIMULATEUR ID / CARTE VRCHAT ----------
const TRUST_LEVELS = [
  { id: 'Visitor', label: 'Visitor', desc: 'Nouveau venu, accès limités', color: '#9ca3af' },
  { id: 'New User', label: 'New User', desc: 'Compte confirmé récemment', color: '#22c55e' },
  { id: 'User', label: 'User', desc: 'Utilisateur habituel confirmé', color: '#3b82f6' },
  { id: 'Known User', label: 'Known User', desc: 'Utilisateur reconnu', color: '#a855f7' },
  { id: 'Trusted User', label: 'Trusted User', desc: 'Confiance élevée de la communauté', color: '#f97316' },
];

const STATUS_OPTIONS = [
  { id: 'join me', label: 'Join Me', color: '#22c55e' },
  { id: 'active', label: 'Active', color: '#3b82f6' },
  { id: 'ask me', label: 'Ask Me', color: '#f59e0b' },
  { id: 'busy', label: 'Busy', color: '#ef4444' },
];

function VRCProfileSimulator() {
  const [displayName, setDisplayName] = useState('VRC_Explorer');
  const [status, setStatus] = useState('active');
  const [trust, setTrust] = useState('Known User');
  const [bio, setBio] = useState('Créateur de contenu 3D & fan d avatars cyberpunk !');
  const [avatar, setAvatar] = useState('Manuka Cyber [STUDIO JINGO]');
  const [world, setWorld] = useState('Winter Solitude & Onsen (par Nocturne)');
  const [uploads, setUploads] = useState(10);

  const currentStatus = STATUS_OPTIONS.find((s) => s.id === status)!;
  const currentTrust = TRUST_LEVELS.find((t) => t.id === trust)!;

  return (
    <div className="max-w-6xl mx-auto px-5 py-8 sm:px-8 space-y-6">
      <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur">
        <div className="flex items-center gap-3">
          <NeonIcon name="user" size={24} />
          <div>
            <h2 className="text-2xl font-black tracking-tight">Simulateur de Profil & Carte d identité VRChat</h2>
            <p className="text-sm text-white/55 mt-1">
              Crée une carte d identité virtuelle VRChat personnalisée d une qualité exceptionnelle ! Choisis ton niveau de confiance, ton statut de jeu, et lie directement un avatar ou un monde.
            </p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[420px_1fr] gap-6">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 space-y-5">
          <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-300 mb-1">Personnalisation</div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Nom d utilisateur VRChat</label>
            <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300" />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Statut en jeu</label>
            <div className="grid grid-cols-2 gap-2">
              {STATUS_OPTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStatus(s.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-semibold transition ${
                    status === s.id
                      ? 'border-cyan-300 bg-cyan-400/15 text-cyan-200'
                      : 'border-white/10 bg-black/20 text-white/60 hover:border-white/25'
                  }`}
                >
                  <span style={{ color: s.color }}>●</span> {s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Niveau de confiance (Trust)</label>
            <select value={trust} onChange={(e) => setTrust(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300">
              {TRUST_LEVELS.map((t) => (
                <option key={t.id} value={t.id}>{t.label} — {t.desc}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Avatar actuel</label>
            <input value={avatar} onChange={(e) => setAvatar(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300" />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Monde favori / arrière-plan</label>
            <input value={world} onChange={(e) => setWorld(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300" />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Biographie / Description</label>
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300 resize-none" />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Nombre d avatars téléversés ({uploads})</label>
            <input type="range" min={0} max={100} value={uploads} onChange={(e) => setUploads(Number(e.target.value))} className="w-full accent-cyan-400" />
          </div>

          <div className="flex gap-3 pt-2">
            <button className="flex-1 rounded-xl bg-emerald-500 text-black font-bold text-xs py-3 hover:bg-emerald-400 transition flex items-center justify-center gap-2">
              <NeonIcon name="save" size={16} className="stroke-black" /> Sauvegarder ma carte
            </button>
            <button onClick={() => { setDisplayName('VRC_Explorer'); setStatus('active'); setTrust('Known User'); setBio('Créateur de contenu 3D & fan d avatars cyberpunk !'); setAvatar('Manuka Cyber [STUDIO JINGO]'); setWorld('Winter Solitude & Onsen (par Nocturne)'); setUploads(10); }} className="rounded-xl border border-white/15 px-4 text-xs text-white/60 hover:bg-white/5 transition">Réinitialiser</button>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/50 mb-4">Aperçu en temps réel</div>

          <div className="relative w-full max-w-md rounded-[32px] border border-white/15 bg-gradient-to-br from-[#10122a] to-[#070818] p-6 shadow-2xl overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-cyan-400 via-violet-500 to-pink-500" />

            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <img src={`https://api.dicebear.com/7.x/pixel-art/svg?seed=${displayName}`} alt="" className="w-16 h-16 rounded-2xl border-2 border-white/20 bg-black/30" />
                <div>
                  <div className="text-lg font-black tracking-tight flex items-center gap-2">
                    {displayName}
                    <span className="text-[10px] px-2 py-0.5 rounded-full border border-white/15 text-white/60 font-mono">ID: {Math.floor(Math.random() * 9000) + 1000}</span>
                  </div>
                  <div className="text-xs text-white/50 flex items-center gap-1 mt-1">
                    <span style={{ color: currentStatus.color }}>●</span> {currentStatus.label} dans le Créen.
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] uppercase tracking-widest text-white/40">VRChat Passport</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1">VERIFIED ACCOUNT</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-2xl bg-black/30 border border-white/10 p-4">
                <div className="text-[10px] uppercase tracking-widest text-white/40 mb-2">Niveau VRChat</div>
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: currentTrust.color }} />
                  <span className="font-bold" style={{ color: currentTrust.color }}>{currentTrust.label}</span>
                </div>
                <div className="text-xs text-white/50 mt-1">{currentTrust.desc}</div>
              </div>

              <div className="rounded-2xl bg-black/30 border border-white/10 p-4">
                <div className="text-[10px] uppercase tracking-widest text-white/40 mb-2">Avatar actuel</div>
                <div className="font-semibold text-white/90">{avatar}</div>
              </div>

              <div className="rounded-2xl bg-black/30 border border-white/10 p-4">
                <div className="text-[10px] uppercase tracking-widest text-white/40 mb-2">Monde actif</div>
                <div className="font-semibold text-white/90 flex items-center gap-2">
                  <NeonIcon name="pin" size={16} /> {world}
                </div>
              </div>

              <div className="rounded-2xl bg-black/30 border border-white/10 p-4">
                <div className="text-[10px] uppercase tracking-widest text-white/40 mb-2">Bio</div>
                <div className="text-sm text-white/70 italic">{bio || 'Aucune bio.'}</div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <div className="bg-white/5 rounded-xl px-4 py-2 border border-white/10">
                  <span className="text-white/40">Avatars uploadés</span>
                  <div className="font-bold text-cyan-300 text-lg">{uploads}</div>
                </div>
                <div className="bg-white/5 rounded-xl px-4 py-2 border border-white/10">
                  <span className="text-white/40">Avatar favori</span>
                  <div className="font-bold text-fuchsia-300">{avatar.split(' ')[0]}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  // Navigation / Pages de garde
  const [isLanding, setIsLanding] = useState(true);
  const [activeTool, setActiveTool] = useState<ActiveTool>('explorer');

  // Authentification
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [authModal, setAuthModal] = useState<'login' | 'signup' | 'reset' | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  // Billing / subscription
  const [subscription, setSubscription] = useState<SubscriptionState>({ plan: 'free', status: 'none' });
  const [billingBusy, setBillingBusy] = useState<PlanId | 'portal' | 'cancel' | null>(null);
  const currentPlan: PlanId = (currentUser?.plan as PlanId) ?? subscription.plan;
  const limits = PLAN_LIMITS[currentPlan];
  const [authUsername, setAuthUsername] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // Upload direct
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [customUploads, setCustomUploads] = useState<SearchResult[]>([]);
  const [upTitle, setUpTitle] = useState('');
  const [upCreator, setUpCreator] = useState('');
  const [upType, setUpType] = useState<ResultType>('Avatar');
  const [upDesc, setUpDesc] = useState('');
  const [upPrice, setUpPrice] = useState(0);
  const [upUrl, setUpUrl] = useState('');
  const [upNsfw, setUpNsfw] = useState(false);
  const [upImage, setUpImage] = useState('');

  // Favoris
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  // Moteur de recherche original
  const [query, setQuery] = useState('');
  const [useAI, setUseAI] = useState(true);
  const [targetMode, setTargetMode] = useState<SearchTargetMode>('keywords');
  const [selectedSources, setSelectedSources] = useState<SourceId[]>([...sourceOptions.map((s) => s.id), 'custom-uploads']);
  const [includeNSFW, setIncludeNSFW] = useState(false);
  const [sortBy, setSortBy] = useState<SortMode>('relevance');
  const [contentMode, setContentMode] = useState<ContentMode>('all');
  const [maxPrice, setMaxPrice] = useState(120);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [sourceStates, setSourceStates] = useState<Record<SourceId, SourceState>>(initialSourceStates);
  const [isSearching, setIsSearching] = useState(false);
  const [page, setPage] = useState(1);
  const [visibleLimit, setVisibleLimit] = useState(24);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [message, setMessage] = useState(`Base de données active. Tape un mot-clé pour lancer le scanner.`);
  const [fetchTargetCount, setFetchTargetCount] = useState(300);
  const [resultsPerPage, setResultsPerPage] = useState(24);
  const [selectedPlatforms, setSelectedPlatforms] = useState<Platform[]>(['PC', 'Quest', 'iOS']);
  const [liveScraperEnabled, setLiveScraperEnabled] = useState(false);
  
  // --- COMMUNITY SCRAPER STATE ---
  const [communityQuery, setCommunityQuery] = useState('');
  const [communityResults, setCommunityResults] = useState<SearchResult[]>([]);
  const [isScrapingWeb, setIsScrapingWeb] = useState(false);
  const [communityVotes, setCommunityVotes] = useState<Record<string, { up: number; down: number; userVote: 'up' | 'down' | null }>>({});

  const rawQueryWords = useMemo(() => {
    return query.toLowerCase().split(/[\s,;+|/]+/).map((s) => s.trim()).filter((s) => s.length >= 2);
  }, [query]);

  // LIVE SCRAPER SIMULATION
  useEffect(() => {
    if (!liveScraperEnabled) return;

    const interval = setInterval(async () => {
      if (!query.trim()) return;
      try {
        const duckQuery = `site:vrchat.com/home/avatar OR site:vrchat.com/home/world ${query.trim()} VRChat`;
        const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(duckQuery)}`;
        const md = await fetchText(readerUrl(url));
        const newHits = parseDuckSearch(md, sourceOptions[0], rawQueryWords, targetMode, includeNSFW, maxPrice, 1);
        
        if (newHits.length > 0) {
          setResults(current => {
            const seen = new Set(current.map(r => r.url));
            const fresh = newHits.filter(r => !seen.has(r.url));
            if (fresh.length === 0) return current;
            setMessage(`📡 Scraper : ${fresh.length} nouveaux éléments découverts en continu.`);
            return [...fresh, ...current];
          });
        }
      } catch (e) {
        console.error("Scraper error", e);
      }
    }, 15000); 

    return () => clearInterval(interval);
  }, [liveScraperEnabled, query, rawQueryWords, targetMode, includeNSFW, maxPrice]);

  // Charger les favoris et uploads depuis le LocalStorage
  useEffect(() => {
    const savedFavs = localStorage.getItem('vrc_favs');
    if (savedFavs) setFavorites(JSON.parse(savedFavs));

    const savedUploads = localStorage.getItem('vrc_uploads');
    if (savedUploads) setCustomUploads(JSON.parse(savedUploads));

    // Auth is now handled by Supabase / demo mode (not localStorage)
  }, []);

  // Load current session on mount and subscribe to auth state changes.
  useEffect(() => {
    getCurrentUser().then(setCurrentUser).catch(() => setCurrentUser(null));
    const unsub = onAuthChange(setCurrentUser);
    return unsub;
  }, []);

  // Load subscription whenever the user changes (and after returning from Checkout).
  useEffect(() => {
    if (!currentUser) {
      setSubscription({ plan: 'free', status: 'none' });
      return;
    }
    let cancelled = false;
    fetchSubscription(currentUser.username)
      .then((sub) => { if (!cancelled) setSubscription(sub); })
      .catch(() => { if (!cancelled) setSubscription({ plan: 'free', status: 'none' }); });
    return () => { cancelled = true; };
  }, [currentUser]);

  // If we just came back from Stripe Checkout (?billing=success), refresh status.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('billing') && currentUser) {
      fetchSubscription(currentUser.username).then(setSubscription).catch(() => {});
      // Clean the URL.
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [currentUser]);

  // --- BILLING ACTIONS ---
  async function handleSelectPlan(plan: PlanId) {
    if (!currentUser) { setAuthModal('signup'); return; }
    if (plan === 'free') {
      await handleCancel();
      return;
    }
    try {
      setBillingBusy(plan);
      await startCheckout({ userId: currentUser.username, email: currentUser.email, plan });
    } catch (err) {
      console.error(err);
      alert('Could not start checkout. Please try again.');
    } finally {
      setBillingBusy(null);
    }
  }

  async function handleOpenPortal() {
    if (!currentUser) return;
    try {
      setBillingBusy('portal');
      await openBillingPortal(currentUser.username);
    } finally {
      setBillingBusy(null);
    }
  }

  async function handleCancel() {
    if (!currentUser) return;
    try {
      setBillingBusy('cancel');
      await cancelSubscription(currentUser.username);
      const sub = await fetchSubscription(currentUser.username);
      setSubscription(sub);
    } finally {
      setBillingBusy(null);
    }
  }

  // --- DAILY USAGE LIMITS (gated by plan) ---
  // Returns true if allowed, false if the daily quota is exceeded.
  function consumeQuota(kind: 'ai' | 'web', max: number): boolean {
    if (max < 0) return true; // unlimited
    const today = new Date().toISOString().slice(0, 10);
    const key = `vrc_usage_${kind}_${today}`;
    const used = Number(localStorage.getItem(key) || '0');
    if (used >= max) return false;
    localStorage.setItem(key, String(used + 1));
    return true;
  }

  const effectiveQuery = useMemo(
    () => (useAI ? enhanceQuery(query, contentMode, targetMode) : query.trim()),
    [contentMode, query, useAI, targetMode],
  );

  const visibleSources = useMemo(
    () => sourceOptions.filter((source) => shouldUseSource(source, contentMode)),
    [contentMode],
  );

  const finalFilteredResults = useMemo(() => {
    let pool = [...results];
    
    // Filtre par Plateforme
    if (selectedPlatforms.length < 3) {
      pool = pool.filter(r => {
        if (!r.platforms) return true; // Si non spécifié, on laisse (fallback)
        return r.platforms.some(p => selectedPlatforms.includes(p));
      });
    }

    if (showOnlyFavorites) {
      pool = pool.filter((r) => favorites.includes(r.id));
    }
    return pool;
  }, [results, showOnlyFavorites, favorites, selectedPlatforms]);

  const sortedResults = useMemo(() => {
    const arr = [...finalFilteredResults];
    if (sortBy === 'price') {
      return arr.sort((a, b) => (a.priceUsd ?? 9999) - (b.priceUsd ?? 9999));
    }
    if (sortBy === 'popularity') {
      return arr.sort((a, b) => (b.likes ?? b.score) - (a.likes ?? a.score));
    }
    if (sortBy === 'shuffle') {
      return arr.sort(() => Math.random() - 0.5);
    }
    return arr.sort((a, b) => b.score - a.score);
  }, [finalFilteredResults, sortBy]);

  const displayedResults = useMemo(() => sortedResults.slice(0, visibleLimit), [sortedResults, visibleLimit]);

  function toggleSource(id: SourceId) {
    setSelectedSources((current) =>
      current.includes(id) ? current.filter((sourceId) => sourceId !== id) : [...current, id],
    );
  }

  function handleFavorite(id: string) {
    const alreadyFav = favorites.includes(id);
    // Enforce favorites limit when adding (removing is always allowed).
    if (!alreadyFav && limits.favorites >= 0 && favorites.length >= limits.favorites) {
      setActiveTool('pricing');
      alert(`Favorites limit reached (${limits.favorites} on your plan). Upgrade to Premium for more.`);
      return;
    }
    const updated = alreadyFav
      ? favorites.filter((favId) => favId !== id)
      : [...favorites, id];
    setFavorites(updated);
    localStorage.setItem('vrc_favs', JSON.stringify(updated));
  }

  // --- ACTIONS AUTH ---
  async function handleAuthSubmit(e: React.FormEvent) {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      if (authModal === 'reset') {
        await sendPasswordReset(authEmail);
        alert(`Password reset email sent to ${authEmail}. Check your inbox.`);
        setAuthModal(null);
        return;
      }
      if (authModal === 'signup') {
        if (!authUsername || !authEmail || !authPassword) {
          setAuthError('All fields are required.');
          return;
        }
        if (authPassword.length < 8) {
          setAuthError('Password must be at least 8 characters.');
          return;
        }
        const user = await signUp({ username: authUsername, email: authEmail, password: authPassword });
        setCurrentUser(user);
      } else {
        if (!authEmail || !authPassword) {
          setAuthError('Email and password are required.');
          return;
        }
        const user = await signIn({ email: authEmail, password: authPassword });
        setCurrentUser(user);
      }
      setAuthModal(null);
      setAuthUsername('');
      setAuthEmail('');
      setAuthPassword('');
    } catch (err: unknown) {
      setAuthError(err instanceof Error ? err.message : 'An error occurred. Please try again.');
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleLogout() {
    await signOut();
    setCurrentUser(null);
    setSubscription({ plan: 'free', status: 'none' });
  }

  // --- ACTIONS UPLOAD ---
  function handleUploadSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!upTitle || !upDesc) {
      alert('Please provide a title and a description.');
      return;
    }

    // Enforce upload limit for the current plan.
    if (limits.avatarUploads >= 0 && customUploads.length >= limits.avatarUploads) {
      setShowUploadModal(false);
      setActiveTool('pricing');
      alert(`Upload limit reached (${limits.avatarUploads} on your plan). Upgrade to Premium for higher limits.`);
      return;
    }

    const newUpload: SearchResult = {
      id: `custom_${Date.now()}`,
      title: upTitle,
      creator: upCreator || currentUser?.username || 'Anonyme',
      description: upDesc,
      type: upType,
      source: 'custom-uploads',
      sourceLabel: 'Upload Direct',
      url: upUrl || 'https://vrchat.com',
      imageUrl: upImage || undefined,
      priceLabel: upPrice === 0 ? 'Gratuit / Free' : `${upPrice} USD`,
      priceUsd: upPrice,
      nsfw: upNsfw,
      score: 150, // Best ranking for direct uploads
      actionLabel: upType === 'Monde' || upType === 'Avatar' ? 'Ouvrir sur VRChat' : 'Télécharger / Accéder',
      likes: 1,
      views: 10,
      tags: [upType.toLowerCase()]
    };

    const updated = [newUpload, ...customUploads];
    setCustomUploads(updated);
    localStorage.setItem('vrc_uploads', JSON.stringify(updated));

    // Injecter directement dans les résultats actuels pour retour visuel instantané
    setResults((current) => [newUpload, ...current]);

    setShowUploadModal(false);
    setUpTitle('');
    setUpDesc('');
    setUpCreator('');
    setUpPrice(0);
    setUpUrl('');
    setUpImage('');
    setUpNsfw(false);

    alert('Félicitations ! Votre création a été publiée directement sur le Hub et est maintenant recherchable.');
  }

  async function performSearch() {
    const trimmedQuery = query.trim();
    if (!trimmedQuery) {
      setMessage('Ajoute au moins un mot-clé (ex: manuka, cyber fox, club, anime girl...).');
      return;
    }

    // Enforce daily AI-search quota for the current plan.
    if (useAI && !consumeQuota('ai', limits.aiSearchesPerDay)) {
      setMessage(`Daily AI search limit reached (${limits.aiSearchesPerDay}/day on your plan). Upgrade to Premium for more.`);
      setActiveTool('pricing');
      return;
    }

    const activeSources = sourceOptions.filter(
      (source) => selectedSources.includes(source.id) && shouldUseSource(source, contentMode),
    );

    setIsSearching(true);
    setResults([]);
    setPage(1);
    setVisibleLimit(resultsPerPage);
    setMessage(`🔎 Scan agressif en cours pour “${trimmedQuery}” • cible ${fetchTargetCount} résultats...`);

    const nextStates = { ...initialSourceStates };
    activeSources.forEach((s) => nextStates[s.id] = 'loading');
    setSourceStates(nextStates);

    // 1) D'abord la base locale MASSIVE + Custom Uploads
    const localHits = searchLocalDB(
      rawQueryWords,
      targetMode,
      contentMode,
      includeNSFW,
      maxPrice,
      selectedSources,
      Math.max(fetchTargetCount, 600),
      customUploads,
      selectedPlatforms
    );

    // 2) Sources live en parallèle, multi-pages
    const pagesPerSource = Math.max(1, Math.min(8, Math.ceil(fetchTargetCount / (activeSources.length || 1) / 8)));

    // Sources standard (hors VRCDB traité à part)
    const standardSources = activeSources.filter(s => s.id !== 'vrcdb');
    const liveJobs = standardSources.map((source) =>
      searchSourceMultiPage(source, trimmedQuery, effectiveQuery, targetMode, pagesPerSource, includeNSFW, maxPrice, rawQueryWords)
        .then((res) => ({ sourceId: source.id, res }))
        .catch(() => ({ sourceId: source.id, res: [] as SearchResult[] }))
    );

    // VRCDB : scraping dédié avec URLs VRChat générées directement
    const hasVrcdb = activeSources.some(s => s.id === 'vrcdb');
    const vrcdbJobPromise = hasVrcdb
      ? searchVrcdb(trimmedQuery, targetMode, includeNSFW, rawQueryWords)
          .then(res => { nextStates['vrcdb'] = 'done'; return res; })
          .catch(() => { nextStates['vrcdb'] = 'done'; return [] as SearchResult[]; })
      : Promise.resolve([] as SearchResult[]);

    const [liveSettled, vrcdbResults] = await Promise.all([Promise.all(liveJobs), vrcdbJobPromise]);

    const liveResults: SearchResult[] = [...vrcdbResults];
    liveSettled.forEach(({ sourceId, res }) => {
      nextStates[sourceId] = 'done';
      liveResults.push(...res);
    });

    const combinedMap = new Map<string, SearchResult>();
    [...localHits, ...liveResults].forEach((r) => {
      if (!combinedMap.has(r.url)) combinedMap.set(r.url, r);
    });

    let finalList = Array.from(combinedMap.values());

    finalList = finalList.map((item) => {
      let boost = 0;
      const title = item.title.toLowerCase();
      rawQueryWords.forEach((w) => {
        if (title.includes(w)) boost += 15;
      });
      return { ...item, score: item.score + boost };
    });

    finalList.sort((a, b) => b.score - a.score);
    if (fetchTargetCount > 0) finalList = finalList.slice(0, fetchTargetCount);

    setResults(finalList);
    setIsSearching(false);
    setMessage(
      finalList.length
        ? `✅ ${finalList.length} résultats stricts trouvés (${localHits.length} locaux/directs + ${liveResults.length} live).`
        : `❌ 0 résultat strict. Revois tes mots-clés ou désactive le filtre créateur.`
    );
  }

  async function handleLoadMore() {
    const hiddenCount = Math.max(0, sortedResults.length - visibleLimit);

    // 1) D'abord on affiche ce qui est déjà en cache
    if (hiddenCount > 0) {
      const revealCount = Math.min(resultsPerPage, hiddenCount);
      setVisibleLimit((prev) => prev + revealCount);
      setMessage(`${revealCount} résultats déjà en cache ont été affichés.`);
      return;
    }

    // 2) Seulement s'il n'y a plus rien à afficher, on cherche plus loin
    if (isLoadingMore) return;

    setIsLoadingMore(true);
    const nextPage = page + 1;

    const activeSources = sourceOptions.filter(
      (source) => selectedSources.includes(source.id) && shouldUseSource(source, contentMode),
    );

    // On scanne plus agressivement au clic "Montrer plus"
    const moreJobs = activeSources.map((source) =>
      searchSourceMultiPage(source, query.trim(), effectiveQuery, targetMode, 4, includeNSFW, maxPrice, rawQueryWords)
    );

    const settled = await Promise.allSettled(moreJobs);
    const moreResults: SearchResult[] = [];
    settled.forEach((item) => {
      if (item.status === 'fulfilled') moreResults.push(...item.value);
    });

    const seen = new Set(results.map((r) => r.url));
    const freshResults = moreResults.filter((r) => !seen.has(r.url));
    const freshCount = freshResults.length;

    if (freshCount > 0) {
      setResults((current) => [...current, ...freshResults]);
      setPage(nextPage);
      setVisibleLimit((prev) => prev + Math.min(resultsPerPage, freshCount));
      setMessage(`${freshCount} nouveaux résultats ont été trouvés et ajoutés.`);
    } else {
      setMessage(`Aucun résultat en plus n'a été trouvé.`);
    }

    setIsLoadingMore(false);
  }

  // --- COMMUNITY SCRAPER LOGIC ---
  async function scrapeTheWeb() {
    if (!communityQuery.trim()) return;
    // Enforce daily Web Discovery quota for the current plan.
    if (!consumeQuota('web', limits.webSearchesPerDay)) {
      setActiveTool('pricing');
      alert(`Daily Web Discovery limit reached (${limits.webSearchesPerDay}/day on your plan). Upgrade to Premium for more.`);
      return;
    }
    setIsScrapingWeb(true);
    setCommunityResults([]);
    // Broad search across the web for VRChat content
    const duckQuery = `VRChat ${communityQuery.trim()} avatar OR world OR asset OR 3D model`;
    const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(duckQuery)}`;
    try {
      const md = await fetchText(readerUrl(url));
      // Use a dummy source for broad parsing
      const broadSource: SourceOption = { id: 'community', label: 'Web Scraper', detail: 'Global Web Search', mode: 'all', color: '#fff', searchUrl: (q) => q };
      const results = parseDuckSearch(md, broadSource, communityQuery.toLowerCase().split(/\s+/).filter(s=>s.length>=2), 'keywords', true, 9999, 1);
      
      // Initialize votes at 0 (no fake stats)
      const votes: Record<string, any> = {};
      results.forEach(r => {
        votes[r.id] = { up: 0, down: 0, userVote: null };
      });
      setCommunityVotes(votes);
      setCommunityResults(results);
    } catch (e) { console.error("Web scrape error", e); }
    setIsScrapingWeb(false);
  }

  function handleCommunityVote(id: string, type: 'up' | 'down') {
    setCommunityVotes(prev => {
      const current = prev[id] || { up: Math.floor(Math.random()*50), down: Math.floor(Math.random()*10), userVote: null as 'up' | 'down' | null };
      let newUp = current.up;
      let newDown = current.down;
      let newUserVote: 'up' | 'down' | null = type;

      // Toggle logic
      if (current.userVote === type) {
        newUserVote = null; // Remove vote
        if (type === 'up') newUp = Math.max(0, newUp - 1);
        else newDown = Math.max(0, newDown - 1);
      } else {
        // Switch vote or new vote
        if (current.userVote === 'up') newUp = Math.max(0, newUp - 1);
        if (current.userVote === 'down') newDown = Math.max(0, newDown - 1);
        if (type === 'up') newUp++;
        else newDown++;
      }
      const next = { ...prev, [id]: { up: newUp, down: newDown, userVote: newUserVote } };
      localStorage.setItem('vrc_community_votes', JSON.stringify(next));
      return next;
    });
  }

  // --- LANDING PAGE DE GARDE ---
  if (isLanding) {
    return (
      <main className="min-h-screen bg-[#030308] text-white flex flex-col justify-between relative overflow-hidden" style={{ fontFamily: 'Inter, sans-serif' }}>
        {/* Animated grid & glows */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(139,92,246,0.35),transparent_40%),radial-gradient(circle_at_80%_80%,rgba(34,211,238,0.2),transparent_40%)] pointer-events-none" />
        <div className="absolute inset-0 animate-[gridMove_25s_linear_infinite] bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

        {/* Top Header Splash */}
        <header className="relative z-10 max-w-7xl mx-auto w-full px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div>
              <div className="font-black tracking-wider text-lg">VRC NEXUS</div>
              <div className="text-[9px] text-cyan-300 font-mono tracking-widest uppercase">One Search. Endless Worlds.</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
             {currentUser ? (
               <div className="flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-2 rounded-full">
                 <img src={currentUser.avatarUrl} alt="" className="w-6 h-6 rounded-full" />
                 <span className="text-sm font-semibold text-white/90">{currentUser.username}</span>
                 {isPremium(currentUser.plan as PlanId) && (
                   <span className="rounded-full bg-gradient-to-r from-amber-400 to-fuchsia-500 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-black">
                     {planDisplayName(currentUser.plan as PlanId)}
                   </span>
                 )}
                 <button onClick={() => handleLogout()} className="text-xs text-red-400 hover:text-red-300 ml-2">Log out</button>
               </div>
             ) : (
               <>
                 <button onClick={() => setAuthModal('login')} className="text-xs font-semibold uppercase tracking-wider text-white/70 hover:text-white transition">Log in</button>
                 <button onClick={() => setAuthModal('signup')} className="bg-white/10 border border-white/20 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider hover:bg-white hover:text-black transition">Sign up</button>
               </>
             )}
           </div>
        </header>

        {/* Hero Section */}
        <section className="relative z-10 max-w-5xl mx-auto px-6 text-center py-12 flex-1 flex flex-col justify-center items-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono mb-6 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>14,832 CRÉATIONS INDEXÉES EN TEMPS RÉEL</span>
          </div>

          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black leading-none tracking-tight">
            Explore le <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-violet-400 to-fuchsia-500">Métaverse</span><br />
            sans limites.
          </h1>

          <p className="mt-6 max-w-2xl text-base sm:text-lg text-white/60 leading-relaxed">
            Bienvenue sur le portail ultime de VRChat. Recherche des milliers d'avatars, de mondes uniques, de vêtements 3D et d'assets depuis toutes les marketplaces (Booth, Jinxxy, Gumroad, VRChat).
          </p>

          {/* Call to Actions */}
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-3xl">
            <button
              onClick={() => { setActiveTool('explorer'); setIsLanding(false); }}
              className="min-h-[58px] rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-600 text-black font-bold uppercase tracking-[0.12em] text-xs shadow-[0_10px_45px_rgba(34,211,238,0.35)] hover:opacity-95 active:scale-[0.985] transition"
            >
              🔍 Indexeur de contenu
            </button>
            <button
              onClick={() => { setActiveTool('bot'); setIsLanding(false); }}
              className="min-h-[58px] rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white font-bold uppercase tracking-[0.12em] text-xs shadow-[0_10px_45px_rgba(139,92,246,0.35)] hover:opacity-95 active:scale-[0.985] transition"
            >
              💬 VRC-Bot Compagnon IA
            </button>
            <button
              onClick={() => { setActiveTool('simulator'); setIsLanding(false); }}
              className="min-h-[58px] rounded-2xl bg-white/5 border border-white/15 text-white font-bold uppercase tracking-[0.12em] text-xs hover:bg-white/10 active:scale-[0.985] transition"
            >
              Simulateur ID VRChat
            </button>
          </div>

          {/* Quick Features List */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 w-full max-w-4xl text-left">
            {[
              ['Strict Search', 'Filtrage obligatoire par mots exacts dans le titre/desc.'],
              ['Creator Search', 'Trouve un auteur/artiste par son pseudo direct.'],
              ['NSFW Filter', 'Mode sécurisé ou accès aux mondes/avatars adultes.'],
              ['Favorites System', 'Simule ton inventaire et sauvegarde tes pépites.'],
            ].map(([title, desc], idx) => (
              <div key={idx} className="border border-white/5 bg-white/[0.02] p-5 rounded-2xl">
                <div className="font-extrabold text-cyan-300 text-sm mb-1">{title}</div>
                <div className="text-xs text-white/50 leading-relaxed">{desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Footer Splash */}
        <footer className="relative z-10 py-8 border-t border-white/5 text-center text-xs text-white/30">
          VRChat Hub © 2026. Non affilié à VRChat Inc. Projet indépendant communautaire.
        </footer>

        {/* Auth Modals nested helper */}
        {renderAuthModal()}
      </main>
    );
  }

  // --- RECTANGLE MODAL AUTHENTIFICATION ---
  function renderAuthModal() {
    if (!authModal) return null;
    const isSignup = authModal === 'signup';
    const isReset = authModal === 'reset';
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
        <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-[#0b0b16] p-8 shadow-2xl animate-[fadeUp_250ms_ease-out_both]">
          <button onClick={() => { setAuthModal(null); setAuthError(''); }} className="absolute right-6 top-6 text-white/40 hover:text-white">
            <NeonIcon name="cross" size={18} />
          </button>

          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <img src="/logo.png" alt="VRC NEXUS" className="w-9 h-9 object-contain rounded-lg" />
              <span className="font-black text-lg text-white">VRC NEXUS</span>
            </div>
            <h2 className="text-2xl font-black tracking-tight text-white">
              {isReset ? 'Reset your password' : isSignup ? 'Create your account' : 'Welcome back'}
            </h2>
            <p className="text-xs text-white/45 mt-1">
              {isReset
                ? 'Enter your email and we\'ll send you a reset link.'
                : isSignup
                  ? 'Join the VRC Nexus community. It\'s free.'
                  : 'Log back in to your VRC Nexus account.'}
            </p>
            {!SUPABASE_CONFIGURED && (
              <div className="mt-3 text-[10px] text-amber-300/80 bg-amber-300/5 border border-amber-300/20 rounded-lg px-3 py-2">
                Demo mode — no Supabase configured. Your account is stored locally.
              </div>
            )}
          </div>

          {authError && (
            <div className="mb-4 flex items-start gap-2 text-xs font-semibold text-pink-400 bg-pink-500/10 border border-pink-500/20 p-3 rounded-xl">
              <NeonIcon name="cross" size={14} className="mt-0.5 shrink-0 stroke-pink-400" />
              {authError}
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-white/45 mb-2">Username</label>
                <input
                  type="text"
                  required={isSignup}
                  autoComplete="username"
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  placeholder="CyberKitsune"
                  minLength={3}
                  maxLength={32}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-300 transition"
                />
              </div>
            )}

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-white/45 mb-2">Email</label>
              <input
                type="email"
                required
                autoComplete={isSignup ? 'email' : 'username'}
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-300 transition"
              />
            </div>

            {!isReset && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/45">Password</label>
                  {!isSignup && (
                    <button type="button" onClick={() => setAuthModal('reset')} className="text-[10px] text-cyan-400 hover:underline">
                      Forgot password?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  required
                  autoComplete={isSignup ? 'new-password' : 'current-password'}
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  minLength={isSignup ? 8 : undefined}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-300 transition"
                />
                {isSignup && <p className="text-[10px] text-white/35 mt-1">Minimum 8 characters</p>}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full min-h-[50px] rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-600 text-black font-extrabold uppercase tracking-widest text-xs hover:opacity-95 active:scale-[0.985] transition disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {authLoading ? (
                <><NeonIcon name="history" size={16} className="animate-spin stroke-black" /> Processing…</>
              ) : isReset ? 'Send reset email' : isSignup ? 'Create account' : 'Log in'}
            </button>

            {isSignup && (
              <p className="text-[10px] text-white/30 text-center leading-relaxed">
                By creating an account you agree to our Terms of Service and Privacy Policy.
              </p>
            )}
          </form>

          <div className="mt-6 pt-5 border-t border-white/10 text-center text-xs text-white/40">
            {isReset ? (
              <button onClick={() => setAuthModal('login')} className="text-cyan-300 hover:underline">← Back to login</button>
            ) : isSignup ? (
              <p>Already have an account? <button onClick={() => { setAuthModal('login'); setAuthError(''); }} className="text-cyan-300 hover:underline">Log in</button></p>
            ) : (
              <p>No account yet? <button onClick={() => { setAuthModal('signup'); setAuthError(''); }} className="text-cyan-300 hover:underline">Sign up for free</button></p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- MODAL UPLOAD DIRECT ---
  function renderUploadModal() {
    if (!showUploadModal) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
        <div className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-[#0d0d18] p-8 shadow-2xl animate-[fadeUp_250ms_ease-out_both] max-h-[92vh] overflow-y-auto"
             style={{scrollbarWidth:'thin'}}>
          <button onClick={() => setShowUploadModal(false)} className="absolute right-6 top-6 text-white/40 hover:text-white">✕</button>

          <h2 className="text-2xl font-black tracking-tight text-white mb-1 flex items-center gap-2">
            <NeonIcon name="upload" size={20} /> Publier une création
          </h2>
          <p className="text-xs text-white/40 mb-6">
            Votre création sera indexée localement et sera instantanément recherchable par n'importe quel utilisateur sur ce Hub.
          </p>

          <form onSubmit={handleUploadSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Titre du modèle / monde</label>
                <input
                  type="text"
                  required
                  value={upTitle}
                  onChange={(e) => setUpTitle(e.target.value)}
                  placeholder="Ex: Cyber Fox Avatar V2"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-300"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Pseudo Créateur</label>
                <input
                  type="text"
                  value={upCreator}
                  onChange={(e) => setUpCreator(e.target.value)}
                  placeholder={currentUser?.username || "Ex: CyberKitsune"}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-300"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Type de création</label>
                <select
                  value={upType}
                  onChange={(e) => setUpType(e.target.value as ResultType)}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white outline-none focus:border-cyan-300"
                >
                  <option value="Avatar">Avatar</option>
                  <option value="Monde">Monde</option>
                  <option value="Asset">Asset / Objet</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Prix (USD)</label>
                <input
                  type="number"
                  min={0}
                  value={upPrice}
                  onChange={(e) => setUpPrice(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white outline-none focus:border-cyan-300"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Description</label>
              <textarea
                required
                rows={3}
                value={upDesc}
                onChange={(e) => setUpDesc(e.target.value)}
                placeholder="Détails, polygones, shaders conseillés, compatibilité Quest..."
                className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-300 resize-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">Lien de la page (ou VRChat Link)</label>
              <input
                type="url"
                value={upUrl}
                onChange={(e) => setUpUrl(e.target.value)}
                placeholder="https://vrchat.com/home/avatar/avtr_..."
                className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-300"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-white/50 mb-2">URL de l'image de couverture (optionnel)</label>
              <input
                type="url"
                value={upImage}
                onChange={(e) => setUpImage(e.target.value)}
                placeholder="https://image-url.com/model.jpg"
                className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-300"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl border border-white/10 bg-black/20">
              <span className="text-xs text-white/70 flex items-center gap-1">
                <NeonIcon name="flame" size={14} /> Marquer comme contenu adulte (NSFW)
              </span>
              <input
                type="checkbox"
                checked={upNsfw}
                onChange={() => setUpNsfw(!upNsfw)}
                className="accent-pink-500 w-5 h-5 cursor-pointer"
              />
            </div>

            <button type="submit" className="w-full min-h-[50px] rounded-xl bg-gradient-to-r from-cyan-400 to-violet-600 text-black font-extrabold uppercase tracking-widest text-xs hover:opacity-95 transition mt-2">
              <span className="flex items-center gap-2"><NeonIcon name="upload" size={16} /> Publier sur le Hub</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#05050a] text-white" style={{ fontFamily: 'Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        @keyframes gridMove { from{ background-position:0 0;} to{ background-position:56px 56px;} }
        @keyframes scanLine { 0%,100%{opacity:.13; transform:translateY(-18px);} 50%{opacity:.78; transform:translateY(180px);} }
        @keyframes barPulse { 0%,100%{ width:22%; transform:translateX(0%);} 50%{ width:88%; transform:translateX(15%);} }
        @keyframes fadeUp { from{ opacity:0; transform:translateY(16px);} to{ opacity:1; transform:translateY(0);} }
        .neon-svg-icon { filter: drop-shadow(0 0 7px rgba(139,92,246,.55)) drop-shadow(0 0 10px rgba(34,211,238,.32)); }
      `}</style>

      {/* Main App Top Header */}
      <section className="relative border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(124,58,237,0.45),transparent_28%),radial-gradient(circle_at_85%_35%,rgba(34,211,238,0.22),transparent_24%),linear-gradient(135deg,#070711_0%,#101022_48%,#05050a_100%)]" />
        <div className="absolute inset-0 animate-[gridMove_18s_linear_infinite] bg-[linear-gradient(rgba(255,255,255,0.045)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.045)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:linear-gradient(to_bottom,black,transparent_92%)]" />
        <div className="absolute left-0 right-0 top-24 h-px animate-[scanLine_4s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-cyan-300/70 to-transparent" />

        <nav className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
          <div className="flex items-center gap-3">
            <div>
              <div onClick={() => setIsLanding(true)} className="text-xs font-semibold uppercase tracking-[0.45em] text-cyan-200/70 cursor-pointer">VRC NEXUS</div>
              <div className="mt-1 text-sm text-white/45">Recherche d avatars, mondes et assets • Mode créateur inclus</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
             {currentUser ? (
               <div className="flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-2 rounded-full text-xs">
                 <img src={currentUser.avatarUrl} alt="" className="w-6 h-6 rounded-full" />
                 <span className="font-semibold text-white/80">{currentUser.username}</span>
                 {isPremium(currentPlan) && (
                   <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-400 to-fuchsia-500 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-black">
                     <NeonIcon name="star" size={10} className="stroke-black" /> {planDisplayName(currentPlan)}
                   </span>
                 )}
                 <button onClick={handleLogout} className="text-[10px] text-red-400 hover:text-red-300 ml-2">Log out</button>
               </div>
             ) : (
               <button onClick={() => setAuthModal('signup')} className="rounded-full bg-white/10 border border-white/20 px-4 py-2 text-xs font-bold uppercase tracking-wider hover:bg-white hover:text-black transition">
                 Sign up / Log in
               </button>
             )}

             <button
               onClick={() => setActiveTool('pricing')}
               className="rounded-full bg-gradient-to-r from-amber-400 to-fuchsia-500 px-4 py-2 text-xs font-black uppercase tracking-wider text-black hover:opacity-90 active:scale-[0.985] transition"
             >
               <span className="flex items-center gap-1"><NeonIcon name="star" size={14} className="stroke-black" /> Premium</span>
             </button>

             <button
               onClick={() => {
                 if (!currentUser) setAuthModal('signup');
                 else setShowUploadModal(true);
               }}
               className="rounded-full bg-cyan-400 px-4 py-2 text-xs font-bold text-black hover:bg-cyan-300 active:scale-[0.985] transition"
             >
               <span className="flex items-center gap-1"><NeonIcon name="plus" size={14} /> Direct Upload</span>
             </button>
           </div>
         </nav>
 
          {/* Tool navigation tabs */}
          <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 pb-6">
            <div className="flex flex-wrap items-center justify-center gap-3">
              {[
                { id: 'explorer', label: 'Content Indexer', icon: <NeonIcon name="search" size={18} /> },
                { id: 'bot', label: 'VRC-Bot AI Companion', icon: <NeonIcon name="chat" size={18} /> },
                { id: 'simulator', label: 'VRChat ID Simulator', icon: <NeonIcon name="user" size={18} /> },
                { id: 'community', label: 'Community Scraper', icon: <NeonIcon name="globalSearch" size={18} /> },
                { id: 'pricing', label: 'Premium Plans', icon: <NeonIcon name="star" size={18} /> },
              ].map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setActiveTool(tool.id as ActiveTool)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full text-sm font-bold uppercase tracking-wider transition border ${
                    activeTool === tool.id
                      ? 'bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-400 text-white border-transparent shadow-[0_0_25px_rgba(139,92,246,0.4)]'
                      : 'bg-white/5 border-white/10 text-white/60 hover:text-white hover:border-cyan-300/40'
                  }`}
                >
                  {tool.icon} {tool.label}
                </button>
              ))}
            </div>
          </div>
 
         {activeTool === 'explorer' && (
         <div className="relative z-10 mx-auto grid max-w-7xl gap-10 px-5 pb-10 pt-8 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pb-16 lg:pt-14">
           <div className="animate-[fadeUp_700ms_ease-out_both]">
             <p className="text-sm uppercase tracking-[0.35em] text-fuchsia-200/70">Moteur de recherche intelligent</p>
            <h1 className="mt-5 max-w-4xl text-5xl font-semibold leading-[0.92] tracking-[-0.06em] sm:text-7xl lg:text-8xl">
              VRChat Hub
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-7 text-white/64">
              Chaque résultat contient <strong className="text-white">obligatoirement</strong> les mots-clés dans son titre ou sa description. Recherche par créateur, tri par prix/popularité, mode NSFW et pagination infinie.
            </p>
          </div>

          <div className="relative min-h-[310px] animate-[fadeUp_900ms_120ms_ease-out_both] overflow-hidden rounded-2xl border border-white/10 bg-black/25 p-6 backdrop-blur-xl">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-300 to-transparent" />
            <div className="flex items-center justify-between text-xs uppercase tracking-[0.28em] text-white/42">
              <span>Live query</span>
              <span>{isSearching ? 'Scanning mots-clés' : 'Ready'}</span>
            </div>
            <div className="mt-10 space-y-3 font-mono text-sm text-cyan-100/80">
              <div className="flex gap-3">
                <span className="text-fuchsia-300">{targetMode === 'creator' ? 'créateur' : 'mots-clés'}</span>
                <span className="truncate">{query.trim() || 'aucun'}</span>
              </div>
              <div className="flex gap-3"><span className="text-fuchsia-300">filtre</span><span>Tous les mots doivent apparaître dans titre/description</span></div>
              <div className="flex gap-3"><span className="text-fuchsia-300">sites</span><span>{selectedSources.length} sélectionnés</span></div>
              <div className="flex gap-3"><span className="text-fuchsia-300">mode</span><span>{includeNSFW ? <span className="flex items-center gap-1"><NeonIcon name="flame" size={14}/> NSFW & SFW inclus</span> : <span className="flex items-center gap-1"><NeonIcon name="shield" size={14}/> SFW uniquement</span>}</span></div>
              <div className="mt-6 h-2 overflow-hidden rounded bg-white/10">
                <div className={`h-full bg-gradient-to-r from-violet-400 via-fuchsia-300 to-cyan-300 ${isSearching ? 'animate-[barPulse_1.15s_ease-in-out_infinite]' : 'w-full'}`} />
              </div>
            </div>
            <div className="absolute bottom-6 left-6 right-6 text-xs text-white/50">
              ⚡ Astuce : Tous les sites sont cherchés par vos mots-clés exacts. Tu peux décocher des sites et ajuster le prix max.
            </div>
           </div>
         </div>
       )}
       </section>
 
       {activeTool === 'explorer' && (
       <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="grid gap-6 lg:grid-cols-[330px_1fr]">
          <aside className="space-y-5">
            <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6 backdrop-blur">
              <div className="mb-5 flex items-center justify-between">
                <h2 className="text-sm font-semibold uppercase tracking-[0.25em] text-white/80 flex items-center gap-2">
                  <NeonIcon name="settings" size={16} /> Paramètres
                </h2>
                <button
                  onClick={() => setSelectedSources([...sourceOptions.map((s) => s.id), 'custom-uploads'])}
                  className="text-xs text-cyan-200/80 hover:text-cyan-100 underline"
                >
                  Tout cocher
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <span className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-white/50 mb-2">
                    <NeonIcon name="cube" size={14} /> Catégorie
                  </span>
                  <select
                    value={contentMode}
                    onChange={(event) => setContentMode(event.target.value as ContentMode)}
                    className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-300/60"
                  >
                    <option value="all">Tout le contenu</option>
                    <option value="avatars">Avatars uniquement</option>
                    <option value="worlds">Mondes uniquement</option>
                    <option value="assets">Assets / Vêtements / Objets</option>
                  </select>
                </div>

                {/* --- PLATEFORMES --- */}
                <div>
                  <span className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-white/50 mb-3">
                    <NeonIcon name="vrHeadset" size={14} /> Plateformes
                  </span>
                  <div className="flex gap-2">
                    {(['PC', 'Quest', 'iOS'] as Platform[]).map((p) => (
                      <button
                        key={p}
                        onClick={() => {
                          setSelectedPlatforms(prev => 
                            prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
                          );
                        }}
                        className={`flex-1 py-2 rounded-xl border text-[11px] font-bold transition ${
                          selectedPlatforms.includes(p)
                            ? 'border-cyan-300 bg-cyan-300/10 text-cyan-200'
                            : 'border-white/10 bg-black/20 text-white/40 hover:border-white/20'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                {/* --- LIVE SCRAPER --- */}
                <div className={`rounded-2xl border transition ${liveScraperEnabled ? 'border-cyan-500/60 bg-cyan-500/5 shadow-[0_0_15px_rgba(34,211,238,0.15)]' : 'border-white/10 bg-black/30'}`}>
                  <label className="flex items-center justify-between gap-3 px-4 py-3 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <NeonIcon name="bolt" size={20} className={liveScraperEnabled ? 'animate-pulse' : 'opacity-40'} />
                      <div>
                        <div className={`text-xs font-bold ${liveScraperEnabled ? 'text-cyan-200' : 'text-white/70'}`}>SCRAPER VRChat LIVE</div>
                        <div className="text-[9px] text-white/45 leading-tight italic">Scan continu (15s)</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setLiveScraperEnabled(!liveScraperEnabled)}
                      className={`relative w-10 h-6 rounded-full transition-colors ${liveScraperEnabled ? 'bg-cyan-500' : 'bg-white/15'}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${liveScraperEnabled ? 'translate-x-4' : 'translate-x-0'}`} />
                    </button>
                  </label>
                </div>

                {/* --- RECHERCHE PAR CRÉATEUR --- */}
                <div>
                  <span className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-white/50 mb-3">
                    <NeonIcon name="search" size={14} /> Mode de recherche
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setTargetMode('keywords')}
                      className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-sm transition ${targetMode === 'keywords' ? 'border-cyan-300/80 bg-cyan-300/15 text-cyan-200 font-semibold' : 'border-white/10 bg-black/30 text-white/60 hover:border-white/25'}`}
                    >
                      <NeonIcon name="tag" size={16} /> Mots-clés
                    </button>
                    <button
                      onClick={() => setTargetMode('creator')}
                      className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-sm transition ${targetMode === 'creator' ? 'border-fuchsia-300/80 bg-fuchsia-300/15 text-fuchsia-200 font-semibold' : 'border-white/10 bg-black/30 text-white/60 hover:border-white/25'}`}
                    >
                      <NeonIcon name="user" size={16} /> Créateur
                    </button>
                  </div>
                </div>

                {/* --- FAVORIS FILTER BUTTON --- */}
                <div>
                  <span className="block text-xs uppercase tracking-[0.2em] text-white/50 mb-2">Favoris</span>
                  <button
                    onClick={() => setShowOnlyFavorites(!showOnlyFavorites)}
                    className={`w-full flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${showOnlyFavorites ? 'border-amber-400 bg-amber-400/20 text-amber-200' : 'border-white/10 bg-black/30 text-white/70 hover:border-white/25'}`}
                  >
                    <span className="flex items-center gap-2"><NeonIcon name="star" size={16} /> Voir mes favoris ({favorites.length})</span>
                    <span className="font-mono text-xs">{showOnlyFavorites ? 'FILTRÉ' : 'OFF'}</span>
                  </button>
                </div>

                <div>
                  <div className="mb-3 text-xs uppercase tracking-[0.2em] text-white/50">Sites de recherche</div>
                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2" style={{ scrollbarWidth: 'thin' }}>
                    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-white/10 bg-black/30 p-3 transition hover:border-cyan-300/40">
                      <input
                        type="checkbox"
                        checked={selectedSources.includes('custom-uploads')}
                        onChange={() => toggleSource('custom-uploads')}
                        className="mt-1 accent-cyan-300"
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-medium text-white/90">Direct Uploads (Hub)</span>
                        <span className="block text-xs text-white/45">Fichiers uploadés par les utilisateurs</span>
                      </span>
                    </label>

                    {visibleSources.map((source) => (
                      <label
                        key={source.id}
                        className="flex cursor-pointer items-start gap-3 rounded-xl border border-white/10 bg-black/30 p-3 transition hover:border-cyan-300/40"
                      >
                        <input
                          type="checkbox"
                          checked={selectedSources.includes(source.id)}
                          onChange={() => toggleSource(source.id)}
                          className="mt-1 accent-cyan-300"
                        />
                        <span className="min-w-0 flex-1">
                          <span className="block text-sm font-medium text-white/90">{source.label}</span>
                          <span className="block text-xs text-white/45">{source.detail}</span>
                        </span>
                        {sourceStates[source.id] !== 'idle' && (
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-cyan-300">
                            {sourceStates[source.id] === 'loading' ? '...' : 'ok'}
                          </span>
                        )}
                      </label>
                    ))}
                  </div>
                </div>

                {/* --- NOUVEAU PARAMÈTRE REQUIS --- */}
                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-white/50 mb-2">
                    <span>Résultats à extraire</span>
                    <span className="text-amber-300 font-semibold">{fetchTargetCount}</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={1000}
                    step={20}
                    value={fetchTargetCount}
                    onChange={(e) => setFetchTargetCount(Number(e.target.value))}
                    className="w-full accent-amber-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-white/50 mb-2">
                    <span>Résultats par page</span>
                    <span className="text-cyan-300 font-semibold">{resultsPerPage}</span>
                  </div>
                  <input
                    type="range"
                    min={6}
                    max={60}
                    step={6}
                    value={resultsPerPage}
                    onChange={(event) => {
                      const newVal = Number(event.target.value);
                      setResultsPerPage(newVal);
                      setVisibleLimit(newVal);
                    }}
                    className="w-full accent-cyan-300"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-white/50 mb-2">
                    <span>Prix maximum</span>
                    <span className="text-cyan-300 font-semibold">${maxPrice}</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={150}
                    value={maxPrice}
                    onChange={(event) => setMaxPrice(Number(event.target.value))}
                    className="w-full accent-cyan-300"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3 pt-2">
                  <button
                    onClick={() => setUseAI((current) => !current)}
                    className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${useAI ? 'border-cyan-300/80 bg-cyan-300/15 text-cyan-200' : 'border-white/10 bg-black/30 text-white/60 hover:border-white/25'}`}
                  >
                    <span className="flex items-center gap-2"><NeonIcon name="bolt" size={16} /> Expansion IA</span>
                    <span className="font-mono text-xs">{useAI ? 'ON' : 'OFF'}</span>
                  </button>

                  <div className={`rounded-2xl border transition overflow-hidden ${includeNSFW ? 'border-pink-500/60 bg-gradient-to-br from-pink-600/20 via-rose-600/10 to-red-600/15 shadow-[0_0_25px_rgba(236,72,153,0.2)]' : 'border-white/10 bg-black/30'}`}>
                    <label className="flex items-center justify-between gap-3 px-4 py-3.5 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <NeonIcon name="flame" size={24} className={`transition ${includeNSFW ? 'opacity-100 scale-110' : 'opacity-40'}`} />
                        <div>
                          <div className={`text-sm font-extrabold tracking-wide ${includeNSFW ? 'text-pink-200' : 'text-white/70'}`}>CONTENU NSFW 18+</div>
                          <div className="text-[10px] text-white/45 leading-tight">Activer les avatars & mondes adultes</div>
                        </div>
                      </div>
                      {/* Toggle switch custom */}
                      <button
                        type="button"
                        onClick={() => setIncludeNSFW(!includeNSFW)}
                        className={`relative w-12 h-7 rounded-full transition-colors shrink-0 ${includeNSFW ? 'bg-gradient-to-r from-pink-500 to-rose-500' : 'bg-white/15'}`}
                      >
                        <span className={`absolute top-0.5 left-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform ${includeNSFW ? 'translate-x-5' : 'translate-x-0'}`} />
                      </button>
                    </label>
                    {includeNSFW && (
                      <div className="px-4 pb-3 pt-1 flex items-start gap-2 text-[10.5px] text-pink-200/80 border-t border-pink-500/20">
                        <NeonIcon name="shield" size={14} className="mt-0.5" />
                        <span>Filtre adulte actif. Les avatars érotiques (DPS) et les clubs 18+ sont visibles.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* COLONNE RÉSULTATS */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[11px] font-bold uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              Nouveau : Algorithme IA de correspondance sémantique activé
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { icon: '🧘', title: 'Mondes relax', desc: 'Onsens chauds, lo-fi lofts, salons de détente.', query: 'onsen chill relax cozy' },
                { icon: '🐱', title: 'Style Anime / Neko', desc: 'La plus grande collection d avatars Booth anime & neko.', query: 'anime neko cat girl cute' },
              ].map((cat) => (
                <button
                  key={cat.title}
                  onClick={() => { setQuery(cat.query); setContentMode('all'); }}
                  className="text-left rounded-2xl border border-white/10 bg-white/[0.03] p-5 hover:border-cyan-300/40 hover:bg-cyan-400/5 transition group"
                >
                  <div className="text-2xl mb-3">{cat.icon}</div>
                  <div className="font-bold text-white group-hover:text-cyan-200 transition">{cat.title}</div>
                  <div className="text-xs text-white/45 mt-1 leading-relaxed">{cat.desc}</div>
                  <div className="text-[10px] text-cyan-400 mt-3 font-semibold">Explorer →</div>
                </button>
              ))}
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 backdrop-blur">
              <div className="flex flex-col gap-3 xl:flex-row">
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  onKeyDown={(event) => event.key === 'Enter' && performSearch()}
                  placeholder={
                    targetMode === 'creator'
                      ? 'Recherche par pseudo créateur... (ex: CyberKitsune, STUDIO JINGO, Dextro...)'
                      : 'Recherche par mots-clés... (ex: manuka, cyber fox, anime girl, club nsfw, hair free...)'
                  }
                  className="min-h-14 flex-1 rounded-xl border border-white/10 bg-black/40 px-5 text-base text-white outline-none transition placeholder:text-white/35 focus:border-cyan-300/60"
                />
                <button
                  onClick={performSearch}
                  disabled={isSearching}
                  className="min-h-14 rounded-xl bg-gradient-to-r from-cyan-400 to-fuchsia-500 px-8 text-sm font-bold uppercase tracking-[0.15em] text-black transition hover:opacity-95 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 shadow-[0_0_20px_rgba(34,211,238,0.25)]"
                >
                  {isSearching ? (
                    <span className="flex items-center gap-2"><NeonIcon name="history" size={16} className="animate-spin" /> Recherche...</span>
                  ) : (
                    <span className="flex items-center gap-2"><NeonIcon name="search" size={16} className="stroke-black" /> Chercher</span>
                  )}
                </button>
              </div>

              <div className="mt-4 flex flex-col gap-3 text-sm text-white/50 sm:flex-row sm:items-center sm:justify-between">
                <div className="truncate text-xs">
                  {targetMode === 'creator'
                    ? `Recherche créateur :`
                    : `Recherche mots-clés :`}{' '}
                  <span className="text-white font-medium">{query.trim() || 'aucune'}</span>
                  <span className="text-fuchsia-400 ml-2">— les résultats contiennent obligatoirement ces mots</span>
                </div>
                <div className="flex gap-1.5">
                  {(['relevance', 'popularity', 'price', 'shuffle'] as SortMode[]).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setSortBy(mode)}
                      className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs uppercase tracking-wider transition ${sortBy === mode ? 'border-cyan-300 bg-white/10 text-cyan-200 font-medium' : 'border-white/10 text-white/50 hover:text-white'}`}
                    >
                      {mode === 'relevance' ? <><NeonIcon name="star" size={14}/> Pertinence</> : 
                       mode === 'popularity' ? <><NeonIcon name="flame" size={14}/> Popularité</> : 
                       mode === 'price' ? <><NeonIcon name="tag" size={14}/> Prix</> : 
                       <><NeonIcon name="play" size={14}/> Shuffle</>}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm text-white/60">
              <span className="text-cyan-300 font-medium">{message}</span>
              <span>Affichés : <strong className="text-white">{displayedResults.length}</strong> sur {sortedResults.length}</span>
            </div>

            {sortedResults.length === 0 ? (
              <div className="grid min-h-[360px] place-items-center rounded-3xl border border-dashed border-white/15 bg-white/[0.02] text-center p-8">
                <div className="max-w-md flex flex-col items-center">
                  <NeonIcon name="cube" size={56} className="mb-5 opacity-50" />
                  <h2 className="text-2xl font-bold tracking-tight text-white">Recherche par mots-clés prête</h2>
                  <p className="mt-3 text-sm leading-6 text-white/50">
                    Tape n'importe quel avatar, monde ou objet (ex: <strong>manuka</strong>, <strong>sakura</strong>, <strong>night club</strong>) puis clique sur Chercher. Les résultats proviennent des pages réelles de chaque site correspondant strictement à ta recherche.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                  {displayedResults.map((result, index) => (
                    <article
                      key={result.id}
                      className="group flex min-h-[340px] animate-[fadeUp_400ms_ease-out_both] flex-col overflow-hidden rounded-3xl border border-white/10 bg-zinc-900/80 transition hover:-translate-y-1 hover:border-cyan-300/50 shadow-lg"
                      style={{ animationDelay: `${Math.min(index, 6) * 45}ms` }}
                    >
                      <a href={result.url} target="_blank" rel="noreferrer" className="relative block h-44 overflow-hidden bg-white/[0.04]">
                        {result.imageUrl ? (
                          <img src={result.imageUrl} alt="" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy" />
                        ) : (
                          <div className="flex h-full items-center justify-center bg-gradient-to-br from-violet-950/40 via-zinc-900 to-black text-xs uppercase tracking-[0.3em] text-white/40">
                            {result.type}
                          </div>
                        )}
                        <div className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/80 px-3 py-[5px] text-[10px] font-semibold uppercase tracking-wider text-cyan-300 backdrop-blur">
                          {result.sourceLabel}
                        </div>
                        {result.nsfw && (
                          <div className="absolute right-3 top-3 rounded-full bg-pink-500 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-md">
                            NSFW
                          </div>
                        )}
                      </a>

                      <div className="flex flex-1 flex-col p-6">
                        <div className="mb-2 flex items-center justify-between text-xs font-medium text-white/50">
                          <div className="flex items-center gap-1.5">
                            <span className="text-fuchsia-300/90 font-mono">#{result.type}</span>
                            {/* Badges Plateforme */}
                            {result.platforms && result.platforms.map(p => (
                              <span key={p} className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider border ${p==='PC' ? 'border-cyan-500/40 text-cyan-300 bg-cyan-500/10' : p==='Quest' ? 'border-violet-500/40 text-violet-300 bg-violet-500/10' : 'border-emerald-500/40 text-emerald-300 bg-emerald-500/10'}`}>
                                {p}
                              </span>
                            ))}
                          </div>
                          <span className="text-emerald-400 font-semibold">{result.priceLabel ?? 'Lien direct'}</span>
                        </div>
                        <h3 className="line-clamp-2 text-lg font-bold leading-snug text-white tracking-tight group-hover:text-cyan-200 transition">
                          {result.title}
                        </h3>
                        {result.creator && <p className="mt-1 text-xs text-white/40">par {result.creator}</p>}
                        <p className="mt-3 line-clamp-3 text-xs leading-relaxed text-white/65 flex-1">{result.description}</p>

                        <div className="mt-6 flex gap-2 pt-4 border-t border-white/10">
                          <a
                            href={result.url}
                            target="_blank"
                            rel="noreferrer"
                            className={`flex-1 rounded-xl flex items-center justify-center gap-1.5 px-4 py-2.5 text-center text-xs font-bold transition active:scale-[0.98] ${
                              result.type === 'Monde' || result.type === 'Avatar'
                                ? 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:opacity-90'
                                : result.priceUsd === 0
                                  ? 'bg-emerald-500 text-black hover:bg-emerald-400'
                                  : 'bg-white text-black hover:bg-cyan-200'
                            }`}
                          >
                            {result.type === 'Monde' ? (
                              <><NeonIcon name="globalSearch" size={14} className="stroke-white" /> Ouvrir sur VRChat</>
                            ) : result.type === 'Avatar' ? (
                              <><NeonIcon name="user" size={14} className="stroke-white" /> Ouvrir sur VRChat</>
                            ) : result.priceUsd === 0 ? (
                              <><NeonIcon name="download" size={14} className="stroke-black" /> Télécharger</>
                            ) : (
                              <><NeonIcon name="link" size={14} /> Voir l original</>
                            )}
                          </a>

                          {/* --- BOUTON FAVORIS --- */}
                          <button
                            onClick={() => handleFavorite(result.id)}
                            className={`flex items-center justify-center rounded-xl border px-3 py-2.5 text-xs transition ${favorites.includes(result.id) ? 'border-amber-400 bg-amber-400/20 text-amber-200' : 'border-white/15 text-white/70 hover:bg-white/10'}`}
                            title="Ajouter aux favoris"
                          >
                            {favorites.includes(result.id) ? <NeonIcon name="heart" size={16} className="fill-current" /> : <NeonIcon name="heart" size={16} />}
                          </button>

                          <button
                            onClick={() => {
                              navigator.clipboard?.writeText(result.url);
                              alert('Lien copié dans le presse-papier !');
                            }}
                            className="flex items-center justify-center rounded-xl border border-white/15 px-3 py-2.5 text-xs text-white/70 transition hover:bg-white/10 hover:text-white"
                            title="Copier le lien"
                          >
                            <NeonIcon name="save" size={16} />
                          </button>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>

                {/* Bouton Montrer Plus */}
                <div className="text-center pt-4 pb-8">
                  <button
                    onClick={handleLoadMore}
                    disabled={isLoadingMore}
                    className="inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 px-8 py-4 text-base font-bold text-white shadow-lg shadow-violet-500/20 hover:opacity-95 active:scale-[0.98] transition disabled:opacity-60 cursor-pointer"
                  >
                    {isLoadingMore ? (
                      <>
                        <span className="animate-spin text-xl">⏳</span>
                        <span>Recherche de nouveaux résultats...</span>
                      </>
                    ) : (
                      <>
                        <NeonIcon name="plus" size={20} />
                        <span>Montrer plus de résultats ({sortedResults.length > visibleLimit ? `${sortedResults.length - visibleLimit} en cache` : 'Rechercher la page suivante'})</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
      )}

      {activeTool === 'bot' && <VRCBot />}
      {activeTool === 'simulator' && (
        limits.profileSimulator ? (
          <VRCProfileSimulator />
        ) : (
          <section className="mx-auto max-w-2xl px-5 py-20 text-center">
            <div className="rounded-3xl border border-amber-400/30 bg-amber-400/5 p-10">
              <NeonIcon name="user" size={48} className="mx-auto mb-4" />
              <h2 className="text-2xl font-black">Profile Simulator is a Premium feature</h2>
              <p className="mt-3 text-white/55">
                The VRChat ID Card &amp; Profile Simulator are available on Nexus Plus and Nexus Pro.
              </p>
              <button
                onClick={() => setActiveTool('pricing')}
                className="mt-6 rounded-xl bg-gradient-to-r from-amber-400 to-fuchsia-500 px-6 py-3 font-black text-black hover:opacity-90 transition"
              >
                View Premium Plans
              </button>
            </div>
          </section>
        )
      )}

      {/* --- PRICING / PREMIUM PLANS VIEW --- */}
      {activeTool === 'pricing' && (
        <section className="mx-auto max-w-6xl px-5 py-12 sm:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <span className="inline-flex items-center gap-2 rounded-full border border-fuchsia-400/30 bg-fuchsia-400/10 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-fuchsia-300">
              <NeonIcon name="star" size={14} /> VRC Nexus Premium
            </span>
            <h2 className="mt-5 text-4xl sm:text-5xl font-black tracking-tight">Choose your plan</h2>
            <p className="mt-4 text-white/55">
              Unlock unlimited searches, premium tools, and priority access. Cancel anytime.
            </p>
          </div>

          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {PLANS.map((p) => {
              const isCurrent = currentPlan === p.id;
              const busy = billingBusy === p.id;
              return (
                <div
                  key={p.id}
                  className={`relative flex flex-col rounded-3xl border p-7 backdrop-blur transition ${
                    p.highlight
                      ? 'border-fuchsia-400/50 bg-gradient-to-b from-fuchsia-500/10 to-cyan-500/5 shadow-[0_0_40px_rgba(217,70,239,0.15)]'
                      : 'border-white/10 bg-white/[0.03]'
                  }`}
                >
                  {p.badge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-400 to-fuchsia-500 px-4 py-1 text-[10px] font-black uppercase tracking-wider text-black">
                      {p.badge}
                    </span>
                  )}
                  <h3 className="text-xl font-black">{p.name}</h3>
                  <p className="mt-1 text-sm text-white/50">{p.tagline}</p>
                  <div className="mt-5 flex items-end gap-2">
                    <span className="text-4xl font-black">{p.priceLabel}</span>
                    <span className="mb-1 text-xs text-white/40">{p.priceSub}</span>
                  </div>

                  <ul className="mt-6 space-y-3 flex-1">
                    {p.features.map((f, i) => (
                      <li key={i} className={`flex items-start gap-2 text-sm ${f.included ? 'text-white/80' : 'text-white/30 line-through'}`}>
                        <NeonIcon name={f.included ? 'check' : 'cross'} size={16} className="mt-0.5 shrink-0" />
                        <span>{f.label}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    disabled={isCurrent || busy}
                    onClick={() => handleSelectPlan(p.id)}
                    className={`mt-7 w-full rounded-xl px-5 py-3 text-sm font-black uppercase tracking-wider transition ${
                      isCurrent
                        ? 'bg-white/10 text-white/40 cursor-default'
                        : p.id === 'free'
                          ? 'bg-white/10 text-white hover:bg-white/15'
                          : 'bg-gradient-to-r from-fuchsia-500 to-cyan-500 text-white hover:opacity-90'
                    }`}
                  >
                    {busy ? 'Processing…' : isCurrent ? 'Current plan' : p.cta}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Subscription management for premium users */}
          {currentUser && isPremium(currentPlan) && (
            <div className="mt-10 rounded-3xl border border-white/10 bg-white/[0.03] p-7">
              <h3 className="text-lg font-black flex items-center gap-2">
                <NeonIcon name="settings" size={18} /> Manage subscription
              </h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-3 text-sm">
                <div className="rounded-xl bg-black/30 border border-white/10 p-4">
                  <div className="text-[10px] uppercase tracking-widest text-white/40">Current plan</div>
                  <div className="mt-1 font-bold text-fuchsia-300">{planDisplayName(currentPlan)}</div>
                </div>
                <div className="rounded-xl bg-black/30 border border-white/10 p-4">
                  <div className="text-[10px] uppercase tracking-widest text-white/40">Status</div>
                  <div className="mt-1 font-bold text-emerald-300 capitalize">
                    {subscription.cancelAtPeriodEnd ? 'Cancels at period end' : subscription.status}
                  </div>
                </div>
                <div className="rounded-xl bg-black/30 border border-white/10 p-4">
                  <div className="text-[10px] uppercase tracking-widest text-white/40">Renews</div>
                  <div className="mt-1 font-bold text-white/80">
                    {subscription.currentPeriodEnd
                      ? new Date(subscription.currentPeriodEnd * 1000).toLocaleDateString()
                      : '—'}
                  </div>
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-3">
                <button
                  onClick={handleOpenPortal}
                  disabled={billingBusy === 'portal'}
                  className="rounded-xl bg-white text-black px-5 py-2.5 text-xs font-black uppercase tracking-wider hover:bg-cyan-200 transition"
                >
                  {billingBusy === 'portal' ? 'Opening…' : 'Billing Portal'}
                </button>
                {!subscription.cancelAtPeriodEnd && (
                  <button
                    onClick={handleCancel}
                    disabled={billingBusy === 'cancel'}
                    className="rounded-xl border border-red-400/40 text-red-300 px-5 py-2.5 text-xs font-black uppercase tracking-wider hover:bg-red-400/10 transition"
                  >
                    {billingBusy === 'cancel' ? 'Cancelling…' : 'Cancel subscription'}
                  </button>
                )}
              </div>
            </div>
          )}
        </section>
      )}

      {/* --- COMMUNITY SCRAPER VIEW --- */}
      {activeTool === 'community' && (
        <section className="mx-auto max-w-6xl px-5 py-10 sm:px-8 space-y-8">
          <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-8 backdrop-blur text-center">
            <h2 className="text-3xl font-black tracking-tight flex items-center justify-center gap-3">
              <NeonIcon name="globalSearch" size={32} /> Scraper Communautaire
            </h2>
            <p className="mt-4 text-white/60 max-w-2xl mx-auto">
              Scrape le web entier pour trouver du contenu VRChat. La communauté vote (Upvote/Downvote) pour décider ce qui mérite d'entrer dans la base de données officielle de VRC NEXUS.
            </p>
            
            <div className="mt-8 flex max-w-2xl mx-auto gap-3">
              <input 
                value={communityQuery}
                onChange={(e) => setCommunityQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && scrapeTheWeb()}
                placeholder="Mots-clés (ex: cyberpunk fox avatar, cozy world...)"
                className="flex-1 rounded-xl border border-white/10 bg-black/40 px-5 text-sm text-white outline-none focus:border-emerald-300/60"
              />
              <button 
                onClick={scrapeTheWeb}
                disabled={isScrapingWeb}
                className="rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 px-6 text-sm font-bold text-black hover:opacity-90 disabled:opacity-50 flex items-center gap-2"
              >
                {isScrapingWeb ? <NeonIcon name="history" size={16} className="animate-spin stroke-black" /> : <NeonIcon name="bolt" size={16} className="stroke-black" />}
                {isScrapingWeb ? 'Scan en cours...' : 'Lancer le Scan'}
              </button>
            </div>
          </div>

          {communityResults.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm text-white/50">
                <span>{communityResults.length} résultats trouvés sur le web</span>
                <span className="text-emerald-400 font-bold">Consensus requis pour ajout à la DB</span>
              </div>
              
              <div className="grid gap-4">
                {communityResults.map((item) => {
                  const votes = communityVotes[item.id] || { up: 0, down: 0, userVote: null };
                  const score = votes.up - votes.down;
                  const consensus = score > 20 ? 'EXCELLENT' : score > 0 ? 'PROMETTEUR' : 'INCERTAIN';
                  const consensusColor = score > 20 ? 'text-emerald-400' : score > 0 ? 'text-yellow-400' : 'text-red-400';

                  return (
                    <div key={item.id} className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 flex flex-col sm:flex-row gap-5 items-start sm:items-center">
                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-bold text-cyan-300 bg-cyan-300/10 px-2 py-0.5 rounded uppercase">{item.type}</span>
                          <span className={`text-[10px] font-black uppercase tracking-wider ${consensusColor}`}>[{consensus}]</span>
                        </div>
                        <h3 className="text-lg font-bold text-white truncate">{item.title}</h3>
                        <p className="text-xs text-white/50 mt-1 line-clamp-2">{item.description}</p>
                        <a href={item.url} target="_blank" rel="noreferrer" className="text-[10px] text-emerald-400 hover:underline mt-2 inline-block truncate max-w-md">{item.url}</a>
                      </div>

                      {/* Voting System */}
                      <div className="flex items-center gap-4 bg-black/20 rounded-xl p-2 border border-white/5">
                        <button 
                          onClick={() => handleCommunityVote(item.id, 'up')}
                          className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition ${votes.userVote === 'up' ? 'bg-emerald-500/20 text-emerald-400' : 'hover:bg-white/5 text-white/40'}`}
                        >
                          <NeonIcon name="chart" size={20} className={votes.userVote === 'up' ? 'stroke-emerald-400' : ''} />
                          <span className="text-xs font-bold">{votes.up}</span>
                        </button>
                        
                        <div className="w-px h-8 bg-white/10" />
                        
                        <button 
                          onClick={() => handleCommunityVote(item.id, 'down')}
                          className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition ${votes.userVote === 'down' ? 'bg-red-500/20 text-red-400' : 'hover:bg-white/5 text-white/40'}`}
                        >
                          <NeonIcon name="lineChart" size={20} className={`rotate-180 ${votes.userVote === 'down' ? 'stroke-red-400' : ''}`} />
                          <span className="text-xs font-bold">{votes.down}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {communityResults.length === 0 && !isScrapingWeb && (
            <div className="text-center py-20 text-white/30">
              <NeonIcon name="globalSearch" size={64} className="mx-auto mb-4 opacity-20" />
              <p>Lance un scan pour voir les résultats du web et voter.</p>
            </div>
          )}
        </section>
      )}

      {/* MODAL WINDOWS */}
      {renderAuthModal()}
      {renderUploadModal()}

      <footer className="border-t border-white/10 px-5 py-8 text-center text-xs leading-6 text-white/35 max-w-5xl mx-auto">
        VRChat Hub est une plateforme de recherche indépendante. Tous les résultats sont filtrés pour contenir tes mots-clés exacts. Liens vers les plateformes officielles (VRChat, Booth, Gumroad, Jinxxy, Itaku, VRCFinder).
      </footer>
    </main>
  );
}
