// ============================================================
//  VRC NEXUS — Supabase client
//  Credentials come from Vite env variables (VITE_ prefix).
//  These are the ANON / publishable key — safe in the frontend.
//  Your service_role key must NEVER appear here.
//
//  How to set up:
//  1. Go to https://supabase.com and create a free project.
//  2. In Project Settings > API, copy:
//     - Project URL  →  VITE_SUPABASE_URL
//     - anon public key  →  VITE_SUPABASE_ANON_KEY
//  3. Add them to your .env file (see .env.example).
//  4. In the Supabase SQL Editor run the migration in supabase/migrations.sql
//     to create the profiles table.
// ============================================================

import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL as string | undefined;
const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY as string | undefined;

export const SUPABASE_CONFIGURED: boolean = !!(SUPABASE_URL && SUPABASE_ANON_KEY);

// If not configured, we export a null-safe stub that surfaces clear errors at runtime.
export const supabase = SUPABASE_CONFIGURED
  ? createClient(SUPABASE_URL!, SUPABASE_ANON_KEY!)
  : (null as unknown as ReturnType<typeof createClient>);

export type AuthError = { message: string };

export interface Profile {
  id: string;
  username: string;
  email: string;
  avatar_url?: string;
  plan: 'free' | 'nexus_plus' | 'nexus_pro';
  stripe_customer_id?: string;
  created_at: string;
}
