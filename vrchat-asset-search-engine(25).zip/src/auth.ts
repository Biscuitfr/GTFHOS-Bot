// ============================================================
//  VRC NEXUS — Auth service
//  Wraps Supabase auth + profile DB operations.
//  When Supabase is not configured it falls back to a local demo
//  so the UI stays fully functional in preview.
// ============================================================

import { supabase, SUPABASE_CONFIGURED, type Profile } from './supabase';
export { SUPABASE_CONFIGURED } from './supabase';

export type { Profile };

// ---- Types ----
export interface AuthUser {
  id: string;
  username: string;
  email: string;
  avatarUrl?: string;
  plan: 'free' | 'nexus_plus' | 'nexus_pro';
}

export interface SignUpPayload {
  username: string;
  email: string;
  password: string;
}

export interface SignInPayload {
  email: string;
  password: string;
}

// ---- Demo-mode helpers (used when Supabase is not configured) ----
const DEMO_USER_KEY = 'vrc_demo_user';

function readDemoUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(DEMO_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveDemoUser(user: AuthUser) {
  localStorage.setItem(DEMO_USER_KEY, JSON.stringify(user));
}

function clearDemoUser() {
  localStorage.removeItem(DEMO_USER_KEY);
}

// ---- Public API ----

/** Sign up a new user. Returns the created user or throws on error. */
export async function signUp({ username, email, password }: SignUpPayload): Promise<AuthUser> {
  if (!SUPABASE_CONFIGURED) {
    // Demo mode: store locally.
    const existingUsers = JSON.parse(localStorage.getItem('vrc_demo_users') || '[]') as AuthUser[];
    if (existingUsers.find((u) => u.email === email)) {
      throw new Error('An account with this email already exists.');
    }
    if (existingUsers.find((u) => u.username === username)) {
      throw new Error('This username is already taken.');
    }
    const newUser: AuthUser = {
      id: `demo_${Date.now()}`,
      username,
      email,
      avatarUrl: `https://api.dicebear.com/8.x/pixel-art/svg?seed=${encodeURIComponent(username)}`,
      plan: 'free',
    };
    localStorage.setItem('vrc_demo_users', JSON.stringify([...existingUsers, newUser]));
    // Also store password hash stub (plaintext in demo — DO NOT do this in production)
    localStorage.setItem(`vrc_demo_pw_${email}`, password);
    saveDemoUser(newUser);
    return newUser;
  }

  // Real Supabase sign-up
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { username },         // stored in raw_user_meta_data → picked up by DB trigger
      emailRedirectTo: window.location.origin,
    },
  });

  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Signup succeeded but no user was returned.');

  // Wait briefly then fetch the auto-created profile.
  const profile = await getProfile(data.user.id);
  return profile;
}

/** Sign in an existing user. Returns the user or throws on error. */
export async function signIn({ email, password }: SignInPayload): Promise<AuthUser> {
  if (!SUPABASE_CONFIGURED) {
    const users = JSON.parse(localStorage.getItem('vrc_demo_users') || '[]') as AuthUser[];
    const user = users.find((u) => u.email === email);
    const storedPw = localStorage.getItem(`vrc_demo_pw_${email}`);
    if (!user || storedPw !== password) {
      throw new Error('Invalid email or password.');
    }
    saveDemoUser(user);
    return user;
  }

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Login failed.');

  return getProfile(data.user.id);
}

/** Sign out the current user. */
export async function signOut(): Promise<void> {
  if (!SUPABASE_CONFIGURED) {
    clearDemoUser();
    return;
  }
  await supabase.auth.signOut();
}

/** Fetch the profile for a user ID. */
export async function getProfile(userId: string): Promise<AuthUser> {
  if (!SUPABASE_CONFIGURED) {
    const user = readDemoUser();
    if (user && user.id === userId) return user;
    throw new Error('Profile not found.');
  }

  // Retry up to 3 times (trigger may take a moment to create the profile row).
  let profile: Profile | null = null;
  for (let i = 0; i < 3; i++) {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    if (data) { profile = data as Profile; break; }
    await new Promise((r) => setTimeout(r, 600));
  }

  if (!profile) throw new Error('Could not load profile. Please try again.');

  return {
    id: profile.id,
    username: profile.username,
    email: profile.email,
    avatarUrl: profile.avatar_url ?? `https://api.dicebear.com/8.x/pixel-art/svg?seed=${encodeURIComponent(profile.username)}`,
    plan: profile.plan,
  };
}

/** Get the currently authenticated session (returns null if not logged in). */
export async function getCurrentUser(): Promise<AuthUser | null> {
  if (!SUPABASE_CONFIGURED) {
    return readDemoUser();
  }
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.user) return null;
  try {
    return await getProfile(session.user.id);
  } catch {
    return null;
  }
}

/** Update the plan field on the profile (called by billing webhooks via server or demo toggle). */
export async function updatePlan(userId: string, plan: 'free' | 'nexus_plus' | 'nexus_pro'): Promise<void> {
  if (!SUPABASE_CONFIGURED) {
    const user = readDemoUser();
    if (user && user.id === userId) saveDemoUser({ ...user, plan });
    return;
  }
  await supabase.from('profiles').update({ plan }).eq('id', userId);
}

/** Change password (authenticated users only). */
export async function changePassword(newPassword: string): Promise<void> {
  if (!SUPABASE_CONFIGURED) {
    const user = readDemoUser();
    if (user) localStorage.setItem(`vrc_demo_pw_${user.email}`, newPassword);
    return;
  }
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw new Error(error.message);
}

/** Send a password-reset email. */
export async function sendPasswordReset(email: string): Promise<void> {
  if (!SUPABASE_CONFIGURED) {
    alert(`[Demo mode] Password reset email would be sent to ${email}.`);
    return;
  }
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/?reset_password=1`,
  });
  if (error) throw new Error(error.message);
}

/** Subscribe to auth state changes (returns an unsubscribe function). */
export function onAuthChange(callback: (user: AuthUser | null) => void): () => void {
  if (!SUPABASE_CONFIGURED) {
    // Nothing to subscribe to in demo mode.
    return () => {};
  }
  const { data } = supabase.auth.onAuthStateChange(async (_event, session) => {
    if (!session?.user) { callback(null); return; }
    try {
      const profile = await getProfile(session.user.id);
      callback(profile);
    } catch {
      callback(null);
    }
  });
  return () => data.subscription.unsubscribe();
}
