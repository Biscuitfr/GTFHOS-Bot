# VRC NEXUS — Full Setup Guide

## Architecture Overview

```
┌──────────────────────────────────────────────────────┐
│  Frontend (Vite + React, this app)                   │
│  - Auth UI (Sign up / Log in / Reset password)       │
│  - Pricing page (Free / Nexus Plus / Nexus Pro)      │
│  - All feature gating (searches, uploads, favorites) │
│  - Reads: VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY  │
│           VITE_API_BASE_URL (Stripe backend)         │
└──────────────┬──────────────────────┬────────────────┘
               │                      │
               ▼                      ▼
┌─────────────────────┐   ┌─────────────────────────────┐
│  Supabase           │   │  Stripe Billing Server      │
│  - Auth (email/pw)  │   │  - Checkout sessions        │
│  - profiles table   │   │  - Billing Portal           │
│  - usage table      │   │  - Webhook sync             │
│  - Row-Level Sec.   │   │  - Updates profile.plan     │
└─────────────────────┘   └─────────────────────────────┘
```

**Demo mode**: When env vars are not set, the app runs fully locally — no real
database, no real payments. Great for previewing the UI.

---

## 1. Supabase — Real Auth & Database

### 1.1 Create a project

1. Go to **https://supabase.com** and create a free project.
2. In **Project Settings → API**, copy:
   - **Project URL** → `VITE_SUPABASE_URL`
   - **anon public** key → `VITE_SUPABASE_ANON_KEY`

### 1.2 Run the database migration

In **SQL Editor → New query**, paste and run the contents of `supabase/migrations.sql`.
This creates:
- `profiles` table (auto-created for each new user via trigger)
- `usage` table (daily search quota tracking)
- Row-Level Security policies

### 1.3 Configure Auth

In **Authentication → Settings**:
- Enable **Email** provider
- Set **Site URL** to your frontend URL (e.g. `http://localhost:5173`)
- Add `http://localhost:5173` to **Redirect URLs**
- Optionally disable email confirmation for development:
  `Authentication → Settings → Enable email confirmations → OFF`

### 1.4 Add env vars to frontend

```bash
cp .env.example .env
```

Fill in:
```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJh...
```

---

## 2. Stripe — Real Billing

### 2.1 Create products

In **Stripe Dashboard → Products**:

| Product | Price | Billing |
|---------|-------|---------|
| Nexus Plus | €4.99 | Monthly recurring |
| Nexus Pro | €9.99 | Monthly recurring |

Copy each **Price ID** (starts with `price_`).

### 2.2 Set up the billing server

```bash
cd server
cp .env.example .env
npm install
```

Fill in `/server/.env`:
```
STRIPE_SECRET_KEY=sk_live_...       # your NEW secret key (revoke the old one!)
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_NEXUS_PLUS=price_...
STRIPE_PRICE_NEXUS_PRO=price_...
APP_BASE_URL=http://localhost:5173
```

Start it:
```bash
npm start
```

### 2.3 Set up webhooks

**For local development:**
```bash
stripe listen --forward-to localhost:8787/api/stripe/webhook
```

**For production:** In Stripe Dashboard → Developers → Webhooks → Add endpoint:
- URL: `https://your-server.com/api/stripe/webhook`
- Events: `checkout.session.completed`, `customer.subscription.*`
- Copy signing secret → `STRIPE_WEBHOOK_SECRET`

### 2.4 Connect frontend to billing server

```
VITE_API_BASE_URL=http://localhost:8787
```

### 2.5 Sync subscription → Supabase profile

After a successful payment the webhook calls `syncSubscriptionFromStripe()` which
updates `subscriptions` in the billing DB. To also update `profiles.plan` in
Supabase (so the frontend sees the new plan instantly), add this to the billing
server's `syncSubscriptionFromStripe` function using the **service_role** key:

```js
import { createClient } from '@supabase/supabase-js';
const adminSupabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
// After upsertSubscription.run(...)
await adminSupabase.from('profiles').update({ plan: sub.status === 'canceled' ? 'free' : plan })
  .eq('stripe_customer_id', customerId);
```

Add to `/server/.env`:
```
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJh...service_role_key...
```

---

## 3. Security notes

- `STRIPE_SECRET_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are **server-only** — never
  in the frontend `.env`.
- `VITE_SUPABASE_ANON_KEY` is safe in the browser (Row-Level Security protects data).
- Stripe webhook signature is always verified (`stripe.webhooks.constructEvent`).
- Never commit your `.env` files.

---

## 4. Feature gating summary

| Feature | Free | Nexus Plus | Nexus Pro |
|---------|------|-----------|-----------|
| AI searches/day | 5 | 100 | ∞ |
| Web Discovery/day | 3 | 50 | ∞ |
| Avatar uploads | 2 | 50 | ∞ |
| Favorites | 10 | 500 | ∞ |
| Profile Simulator & ID Card | ✗ | ✓ | ✓ |
| VRC Bot tier | Basic | Premium | Advanced |
| Search priority | Slow | Fast | Priority |
