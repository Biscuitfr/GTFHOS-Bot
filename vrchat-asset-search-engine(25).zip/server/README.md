# VRC Nexus — Stripe Billing Server

This is the **server-side** part of VRC Nexus billing. It keeps all Stripe secrets
server-side and is the source of truth for subscription state (synced via webhooks).

The frontend (the Vite app) never sees your secret key — it only calls the public
endpoints below.

## 1. Setup

```bash
cd server
cp .env.example .env      # then fill in your real values
npm install
npm start
```

## 2. Stripe Dashboard configuration

1. Create two **recurring** Products/Prices:
   - **Nexus Plus** — €4.99 / month
   - **Nexus Pro** — €9.99 / month
2. Copy each Price ID into `.env`:
   - `STRIPE_PRICE_NEXUS_PLUS`
   - `STRIPE_PRICE_NEXUS_PRO`
3. Put your secret key in `STRIPE_SECRET_KEY` (use `sk_test_...` while testing).

## 3. Webhooks (required for DB sync)

In **Developers > Webhooks**, add an endpoint pointing to:

```
https://YOUR_SERVER/api/stripe/webhook
```

Subscribe to these events:

- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`

Copy the **Signing secret** into `STRIPE_WEBHOOK_SECRET`.

For local testing use the Stripe CLI:

```bash
stripe listen --forward-to localhost:8787/api/stripe/webhook
```

## 4. Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/stripe/create-checkout-session` | Subscribe / upgrade / downgrade |
| POST | `/api/stripe/create-portal-session` | Open the Stripe Billing Portal |
| POST | `/api/stripe/cancel-subscription` | Cancel at period end |
| GET  | `/api/stripe/subscription/:userId` | Read current subscription status |
| POST | `/api/stripe/webhook` | Stripe webhook (raw body) |

## 5. Connect the frontend

In the frontend project root create a `.env` file:

```
VITE_API_BASE_URL=http://localhost:8787
```

When this is set, the Pricing page calls the real Stripe backend.
If it is **not** set, the frontend runs in a safe **demo mode** (no real charges)
so you can preview the UI.

## Security notes

- Secret key & webhook secret are **only** read from `process.env`.
- The webhook route uses the raw body and verifies the Stripe signature.
- Subscription state is always re-fetched from Stripe (`syncSubscriptionFromStripe`),
  never trusted from the client.
