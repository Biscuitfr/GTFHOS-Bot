// ============================================================
//  VRC NEXUS — Stripe Billing Server
//  - Stripe Checkout (subscriptions)
//  - Upgrade / Downgrade
//  - Cancel subscription
//  - Billing Portal
//  - Webhooks (source of truth for subscription state)
//  - Subscriptions stored in SQLite and synced via webhooks
//
//  All secret keys are read from environment variables (server-side only).
// ============================================================

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import Stripe from 'stripe';
import Database from 'better-sqlite3';

// ---------- Required env validation ----------
const {
  STRIPE_SECRET_KEY,
  STRIPE_WEBHOOK_SECRET,
  STRIPE_PRICE_NEXUS_PLUS,
  STRIPE_PRICE_NEXUS_PRO,
  APP_BASE_URL = 'http://localhost:5173',
  PORT = 8787,
  CORS_ORIGINS = 'http://localhost:5173',
} = process.env;

if (!STRIPE_SECRET_KEY) {
  console.error('FATAL: STRIPE_SECRET_KEY is not set. Refusing to start.');
  process.exit(1);
}

const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' });

// Map our internal plan ids to Stripe price ids (configured via env).
const PLAN_TO_PRICE = {
  nexus_plus: STRIPE_PRICE_NEXUS_PLUS,
  nexus_pro: STRIPE_PRICE_NEXUS_PRO,
};
const PRICE_TO_PLAN = Object.fromEntries(
  Object.entries(PLAN_TO_PRICE).map(([plan, price]) => [price, plan]),
);

// ---------- Database (SQLite) ----------
const db = new Database('billing.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE,
    stripe_customer_id TEXT
  );
  CREATE TABLE IF NOT EXISTS subscriptions (
    id TEXT PRIMARY KEY,                 -- Stripe subscription id
    user_id TEXT,
    customer_id TEXT,
    plan TEXT,                           -- free | nexus_plus | nexus_pro
    status TEXT,                         -- active | trialing | past_due | canceled | ...
    current_period_end INTEGER,
    cancel_at_period_end INTEGER DEFAULT 0,
    updated_at INTEGER
  );
`);

const upsertUser = db.prepare(`
  INSERT INTO users (id, email, stripe_customer_id)
  VALUES (@id, @email, @stripe_customer_id)
  ON CONFLICT(id) DO UPDATE SET
    email = excluded.email,
    stripe_customer_id = COALESCE(excluded.stripe_customer_id, users.stripe_customer_id)
`);
const getUser = db.prepare('SELECT * FROM users WHERE id = ?');
const getUserByCustomer = db.prepare('SELECT * FROM users WHERE stripe_customer_id = ?');
const upsertSubscription = db.prepare(`
  INSERT INTO subscriptions (id, user_id, customer_id, plan, status, current_period_end, cancel_at_period_end, updated_at)
  VALUES (@id, @user_id, @customer_id, @plan, @status, @current_period_end, @cancel_at_period_end, @updated_at)
  ON CONFLICT(id) DO UPDATE SET
    plan = excluded.plan,
    status = excluded.status,
    current_period_end = excluded.current_period_end,
    cancel_at_period_end = excluded.cancel_at_period_end,
    updated_at = excluded.updated_at
`);
const getSubByCustomer = db.prepare(
  "SELECT * FROM subscriptions WHERE customer_id = ? ORDER BY updated_at DESC LIMIT 1",
);

// ---------- App ----------
const app = express();
const allowedOrigins = CORS_ORIGINS.split(',').map((s) => s.trim());
app.use(cors({ origin: allowedOrigins, credentials: true }));

// IMPORTANT: the webhook route needs the RAW body, so mount it BEFORE express.json().
app.post('/api/stripe/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const obj = event.data.object;
        const subscriptionId = obj.subscription || obj.id;
        if (subscriptionId && typeof subscriptionId === 'string') {
          syncSubscriptionFromStripe(subscriptionId);
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    console.error('Error handling webhook event:', err);
  }

  res.json({ received: true });
});

// JSON parser for all other routes.
app.use(express.json());

// Pull the latest subscription from Stripe and write it to our DB (source of truth = Stripe).
async function syncSubscriptionFromStripe(subscriptionId) {
  const sub = await stripe.subscriptions.retrieve(subscriptionId);
  const customerId = sub.customer;
  const priceId = sub.items.data[0]?.price?.id;
  const plan = PRICE_TO_PLAN[priceId] || 'free';
  const user = getUserByCustomer.get(customerId);

  upsertSubscription.run({
    id: sub.id,
    user_id: user?.id || null,
    customer_id: customerId,
    plan: sub.status === 'canceled' ? 'free' : plan,
    status: sub.status,
    current_period_end: sub.current_period_end,
    cancel_at_period_end: sub.cancel_at_period_end ? 1 : 0,
    updated_at: Math.floor(Date.now() / 1000),
  });
}

// Ensure we have a Stripe customer for this user.
async function getOrCreateCustomer({ userId, email }) {
  let user = getUser.get(userId);
  if (user?.stripe_customer_id) return user.stripe_customer_id;

  const customer = await stripe.customers.create({
    email,
    metadata: { app_user_id: userId },
  });
  upsertUser.run({ id: userId, email, stripe_customer_id: customer.id });
  return customer.id;
}

// ---------- Create Checkout Session (subscribe / upgrade / downgrade) ----------
app.post('/api/stripe/create-checkout-session', async (req, res) => {
  try {
    const { userId, email, plan } = req.body;
    if (!userId || !email || !PLAN_TO_PRICE[plan]) {
      return res.status(400).json({ error: 'Missing or invalid userId, email, or plan.' });
    }

    const customerId = await getOrCreateCustomer({ userId, email });

    // If user already has an active subscription, switch the plan on the existing
    // subscription (proration handles upgrade/downgrade) instead of new checkout.
    const existing = getSubByCustomer.get(customerId);
    if (existing && ['active', 'trialing', 'past_due'].includes(existing.status)) {
      const sub = await stripe.subscriptions.retrieve(existing.id);
      const itemId = sub.items.data[0].id;
      await stripe.subscriptions.update(existing.id, {
        cancel_at_period_end: false,
        proration_behavior: 'create_prorations',
        items: [{ id: itemId, price: PLAN_TO_PRICE[plan] }],
      });
      await syncSubscriptionFromStripe(existing.id);
      return res.json({ updated: true });
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      line_items: [{ price: PLAN_TO_PRICE[plan], quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${APP_BASE_URL}/?billing=success`,
      cancel_url: `${APP_BASE_URL}/?billing=cancel`,
      subscription_data: { metadata: { app_user_id: userId, plan } },
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create checkout session.' });
  }
});

// ---------- Billing Portal (manage / update payment / cancel) ----------
app.post('/api/stripe/create-portal-session', async (req, res) => {
  try {
    const { userId } = req.body;
    const user = getUser.get(userId);
    if (!user?.stripe_customer_id) {
      return res.status(400).json({ error: 'No Stripe customer for this user.' });
    }
    const portal = await stripe.billingPortal.sessions.create({
      customer: user.stripe_customer_id,
      return_url: `${APP_BASE_URL}/?billing=portal_return`,
    });
    res.json({ url: portal.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create billing portal session.' });
  }
});

// ---------- Cancel subscription (at period end) ----------
app.post('/api/stripe/cancel-subscription', async (req, res) => {
  try {
    const { userId } = req.body;
    const user = getUser.get(userId);
    const sub = user?.stripe_customer_id ? getSubByCustomer.get(user.stripe_customer_id) : null;
    if (!sub) return res.status(400).json({ error: 'No active subscription.' });

    await stripe.subscriptions.update(sub.id, { cancel_at_period_end: true });
    await syncSubscriptionFromStripe(sub.id);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to cancel subscription.' });
  }
});

// ---------- Get current subscription status for a user ----------
app.get('/api/stripe/subscription/:userId', (req, res) => {
  const user = getUser.get(req.params.userId);
  if (!user?.stripe_customer_id) {
    return res.json({ plan: 'free', status: 'none' });
  }
  const sub = getSubByCustomer.get(user.stripe_customer_id);
  if (!sub) return res.json({ plan: 'free', status: 'none' });
  res.json({
    plan: sub.plan,
    status: sub.status,
    currentPeriodEnd: sub.current_period_end,
    cancelAtPeriodEnd: !!sub.cancel_at_period_end,
  });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`VRC Nexus billing server running on http://localhost:${PORT}`);
});
